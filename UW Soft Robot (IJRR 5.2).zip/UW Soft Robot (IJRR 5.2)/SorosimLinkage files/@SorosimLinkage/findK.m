%Computes the generalized stiffness matrix for the linkage
%Last modified by Anup Teejo Mathew 02.03.2022
function K = findK(Tr,varargin) %NxN matrix for independent basis, NX1 for dependent basis if any

if nargin==3
    q = varargin{1};
    t = varargin{2};
else
    q = zeros(Tr.ndof,1);
    t = 0;
end


dof_start = 1;

if ~Tr.dependent %typical case
    K = zeros(Tr.ndof,Tr.ndof); %NxN matrix 
    for i=1:Tr.N

        VTwists = Tr.CVTwists{i};
        dof_here = VTwists(1).dof;
        if Tr.VLinks(Tr.LinkIndex(i)).Kj==0
            K(dof_start:dof_start+dof_here-1,dof_start:dof_start+dof_here-1) = zeros(VTwists(1).dof);
        else
            if isequal(size(Tr.VLinks(Tr.LinkIndex(i)).Kj),[VTwists(1).dof,VTwists(1).dof])
                K(dof_start:dof_start+dof_here-1,dof_start:dof_start+dof_here-1) = Tr.VLinks(Tr.LinkIndex(i)).Kj;
            else
                uiwait(msgbox('Incorrect joint stiffness matrix dimensions','Error','error'));
                return
            end
        end

        dof_start = dof_start+dof_here;  
        for j=1:(Tr.VLinks(Tr.LinkIndex(i)).npie)-1 %for the rest of soft link divisions

            ld       = Tr.VLinks(Tr.LinkIndex(i)).lp{j};
            Es       = VTwists(j+1).Es;
            dof_here = VTwists(j+1).dof;
            Ws       = VTwists(j+1).Ws;
            nip       = VTwists(j+1).nip;

            Ktemp  = zeros(dof_here,dof_here);

            %scaling of quantities
            Lscale = ld;
            dBqdq  = VTwists(j+1).B;
            
            for ii=2:nip-1
                if Ws(ii)>0
                    Es_here = Es((ii-1)*6+1:ii*6,:);
                    %scaling
                    Es_here(1:3,:) = Es_here(1:3,:)/Lscale^3;
                    Es_here(4:6,:) = Es_here(4:6,:)/Lscale;

                    Ktemp = Ktemp+Ws(ii)*dBqdq((ii-1)*6+1:ii*6,:)'*Es_here*dBqdq((ii-1)*6+1:ii*6,:);
                end
            end
            K(dof_start:dof_start+dof_here-1,dof_start:dof_start+dof_here-1) = Ktemp*Lscale^2;
            dof_start  = dof_start+dof_here;
        end
    end
else
    K = zeros(Tr.ndof,1);
    for i=1:Tr.N
    
        VTwists = Tr.CVTwists{i};
        dof_here = VTwists(1).dof;
        
        if Tr.VLinks(Tr.LinkIndex(i)).Kj==0
            K(dof_start:dof_start+dof_here-1) = zeros(VTwists(1).dof,1);
        else  
            if isequal(size(Tr.VLinks(Tr.LinkIndex(i)).Kj),[VTwists(1).dof,VTwists(1).dof])
                q_here = q(dof_start:dof_start+dof_here-1);
                K(dof_start:dof_start+dof_here-1) = Tr.VLinks(Tr.LinkIndex(i)).Kj*q_here;
            else
                uiwait(msgbox('Incorrect joint stiffness matrix dimensions','Error','error'));
                return
            end
        end

        dof_start = dof_start+dof_here;
        
        for j=1:(Tr.VLinks(Tr.LinkIndex(i)).npie)-1 %for the rest of soft link divisions

            ld       = Tr.VLinks(Tr.LinkIndex(i)).lp{j};
            Es       = VTwists(j+1).Es;
            dof_here = VTwists(j+1).dof;
            Ws       = VTwists(j+1).Ws;
            nip       = VTwists(j+1).nip;
            Xs       = VTwists(j+1).Xs;

            Ktemp  = zeros(dof_here,1);

            %scaling of quantities
            Lscale        = ld;

            Bh = VTwists(j+1).Bh;
            
            for ii=2:nip-1
                if Ws(ii)>0
                    if strcmp(VTwists(j+1).Type,'Custom Dependent (q,t)')
                        q_here = q(dof_start:dof_start+dof_here-1); 
                        [Bq_here,dBqdq_here] = Bh(Xs(ii),q_here,t);
                    elseif strcmp(VTwists(j+1).Type,'Custom Dependent (q)')
                        q_here = q(dof_start:dof_start+dof_here-1); 
                        [Bq_here,dBqdq_here] = Bh(Xs(ii),q_here);
                    elseif strcmp(VTwists(j+1).Type,'Custom Dependent (t)')
                        [dBqdq_here,~,~,xit_here] = Bh(Xs(ii),t);
                        Bq_here = dBqdq_here*q_here+xit_here;
                    else
                        dBqdq_here = VTwists(j+1).B((ii-1)*6+1:ii*6,:);
                        Bq_here = dBqdq_here*q_here;
                    end
                    Es_here = Es((ii-1)*6+1:ii*6,:);
                    %scaling
                    Es_here(1:3,:) = Es_here(1:3,:)/Lscale^3;
                    Es_here(4:6,:) = Es_here(4:6,:)/Lscale;

                    Ktemp = Ktemp+Ws(ii)*dBqdq_here'*Es_here*Bq_here; %Bq is xi
                end
            end
            K(dof_start:dof_start+dof_here-1) = Ktemp*Lscale^2;
            dof_start  = dof_start+dof_here;
        end
    end
end

end