%run this to create the flagella robot

Shell = SorosimLink; %Rigid, Jointtype: F, Density: 2900, Length: 30e-3, Radius: 90e-3

%%
rho_water = 1000;

% Geometrical input for Shell

% Mc          = 1.2675;                           % [Kg] weight of the canister (to balance all other forces)
ro_c        =2900;                              % [Kg/m^3] densità canister (alluminio)

% Geometrical input dello shaft

Ls          =15e-3;                         % [m] Lunghezza

% Drag body 
Cmbx        =2.5;                                      % [-] coeff. viscosità 
Cmby        =0;                                      % [-] coeff. viscosità 
Cmbz        =Cmby;                                      % [-] coeff. viscosità 
Clbx        =1;                                      % [-] coeff. viscosità 
Clby        =1;                                      % [-] coeff. viscosità moto
Clbz        =Clbx;                                      % [-] coeff. viscosità 

%external part
Rb_e        =90e-3;                              % [m] Raggio 
Lcyl_e      =30e-3;                              % [m] Lunghezza
Afr_e       =pi*Rb_e^2;                          % [m^2] frontale
Ala_e       =(pi+4)*Rb_e^2;                      % [m^2] laterale
Asu_e       =8*pi*Rb_e^2;                        % [m^2] superficiale
Vsp_e       =4*pi*Rb_e^3/3;                      % [m^3] volume sfera
Vcyl_e      =Afr_e*Lcyl_e;                       % [m^3] volume cilindro
Vc_e        =Vsp_e+Vcyl_e;                       % [m^3] volume totale esterno
deltaCyl_e  =Lcyl_e/(2*Rb_e);
Ibx_e       =pi*Rb_e^5*(deltaCyl_e/6*(3+4*(deltaCyl_e)^2)+4/3*(83/320+(deltaCyl_e+3/8)^2));
Iby_e       =pi*Rb_e^5*(deltaCyl_e+8/15);
Ibz_e       =Ibx_e;
Mc_e        =ro_c*diag([Ibx_e Iby_e Ibz_e Vc_e Vc_e Vc_e]); % [Kgm^2] inerzia parte esterna


%internal part
Rb_i        =85e-3;                             % [m] Raggio interno (5mm spessore)
Lcyl_i      =Lcyl_e;                            % [m] Lunghezza cilindro
Afr_i       =pi*Rb_i^2;                         % [m^2] frontale
Ala_i       =(pi+4)*Rb_i^2;                     % [m^2] laterale
Asu_i       =8*pi*Rb_i^2;                       % [m^2] superficiale
Vsp_i       =4*pi*Rb_i^3/3;                     % [m^3] volume sfera
Vcyl_i      =pi*Rb_i^2*Lcyl_i;                  % [m^3] volume cilindro
Vc_i        =Vsp_i+Vcyl_i;                      % [m^3] volume totale interno canister 
deltaCyl_i  =Lcyl_i/(2*Rb_i);
Ibx_i       =pi*Rb_i^5*(deltaCyl_i/6*(3+4*(deltaCyl_i)^2)+4/3*(83/320+(deltaCyl_i+3/8)^2));
Iby_i       =pi*Rb_i^5*(deltaCyl_i+8/15);
Ibz_i       =Ibx_i;
Mc_i        =ro_c*diag([Ibx_i Iby_i Ibz_i Vc_i Vc_i Vc_i]); % [Kgm^2] inerzia parte interna

% combined parts
Vcyl_net    =Vcyl_e-Vcyl_i;   
Vsp_net     =Vsp_e-Vsp_i; 
Vc_net      =Vc_e-Vc_i;                         % [m^3] volume canister ne
Mc          =Mc_e - Mc_i;                       % [Kgm^2] inertia matrix totale canister

mc_net      =ro_c*Vc_net;                       % [Kg] massa canister
Rb          =Rb_e;                              % [m]
Lcyl        =Lcyl_e;                            % [m] Lunghezza
Lb          =Lcyl;

% drag lift body
a           =Rb+Lcyl/2;                         % [m] length ellipsoid (from the center)
b           =Rb;                                % [m] length ellipsoid (from the center)
ecce        =1-(b/a)^2;                         % [-] eccentricita ellipsoid
% ecce        =3/4;                         % [-] eccentricita ellipsoid
alpha       =2*(1-ecce^2)*...
             (0.5*log((1+ecce)/(1-ecce))-ecce)/...
             (ecce^3);                                  % [-] added mass term
beta        =1/ecce^2-(1-ecce^2)*log((1+ecce)/(1-ecce))/...
             (2*ecce^3);                                % [-] added mass term
% gamma       =9*Rb^2*(alpha-beta)/...
%              (5*(5*(beta-alpha)-6));                  % [m^2] added mass term

gamma       =((b^2-a^2)^2*(alpha-beta))/...             % [m^2] added mass term
               5*(2*(b^2-a^2)+(b^2+a^2)*(beta-alpha));
Db          =0.5*rho_water*diag([Cmbx*Ala_e*Rb^3 Cmby*Asu_e*Rb^3 Cmbz*Ala_e*Rb^3 Clbx*Ala_e Clby*Afr_e Clbz*Ala_e]); % drag coef matrix
Agb         =rho_water*(Vcyl_e+Vsp_e)*diag([gamma 0 gamma beta/(2-beta) alpha/(2-alpha) beta/(2-beta)]);     % massa da aggiungere

% Pesi interni: batteria con case, Arbotix e pesetti
m_battery       =0.9;                                   %[Kg]
m_arbotix       =0.41;                                  %[Kg]
m_weight        =m_battery+m_arbotix;                   %[Kg

Lx_weight   =2*Rb_i/3;                                  %[m] ipotizzo altezza di 2/3 raggio interno 
eccew       =10e-3;                                     %[m] distanza in x e z del peso interno
ecceyw      =7e-3;                                     %[m] distanza in y del peso interno
Ly_weight   =Lcyl_i/2+Rb_i/2;                           %[m]
Lz_weight   =2*Rb_i;                                    %[m]

Ix_weight   =(Ly_weight^2+Lz_weight^2)/12;              %[m^2]
Iy_weight   =(Lx_weight^2+Lz_weight^2)/12;              %[m^2]
Iz_weight   =(Lx_weight^2+Ly_weight^2)/12;              %[m^2]

M0_weight   =m_weight*diag([Ix_weight Iy_weight Iz_weight  1 1 1]);
gbw         =[cos(-pi/4) 0 sin(-pi/4) -eccew*cos(pi/4); 0 1 0 ecceyw+Ly_weight/2;...
              -sin(-pi/4) 0 cos(-pi/4) -eccew*sin(pi/4); 0 0 0 1]; %riporto tutto nel rif. canister
M_weight    =dinamico_coAdjoint(gbw)*M0_weight*dinamico_Adjoint(gbw^-1); 

%Translation  
Trasl1      =[1 0 0 Rb*cos(pi/4); 0 1 0 -(Lcyl/2+Rb*sin(pi/4)); 0 0 1 0; 0 0 0 1];
Trasl2      =[1 0 0 -Rb*cos(pi/4); 0 1 0 -(Lcyl/2+Rb*sin(pi/4)); 0 0 1 0; 0 0 0 1];
Trasl3      =[1 0 0 0; 0 1 0 -(Lcyl/2+Rb*sin(pi/4)); 0 0 1 Rb*cos(pi/4); 0 0 0 1];
Trasl4      =[1 0 0 0; 0 1 0 -(Lcyl/2+Rb*sin(pi/4)); 0 0 1 -Rb*cos(pi/4); 0 0 0 1];

%Rotations
Rot1        =[cos(-pi/4) -sin(-pi/4) 0 0; sin(-pi/4) cos(-pi/4) 0 0; 0 0 1 0; 0 0 0 1]; %Rz(-pi/4)
Rot2        =[cos(pi+pi/4) -sin(pi+pi/4) 0 0; sin(pi+pi/4) cos(pi+pi/4) 0 0; 0 0 1 0; 0 0 0 1]*...
             [1 0 0 0; 0 cos(pi) -sin(pi) 0 ;0 sin(pi) cos(pi) 0; 0 0 0 1]; %Rz(pi+pi/4)*Rx(pi)
Rot3        =[cos(-pi/2) -sin(-pi/2) 0 0; sin(-pi/2) cos(-pi/2) 0 0; 0 0 1 0; 0 0 0 1]*...
             [cos(-pi/2+pi/4) 0 sin(-pi/2+pi/4) 0; 0 1 0 0; -sin(-pi/2+pi/4) 0 cos(-pi/2+pi/4) 0; 0 0 0 1]*...
             [1 0 0 0; 0 cos(pi/2) -sin(pi/2) 0 ;0 sin(pi/2) cos(pi/2) 0; 0 0 0 1]; %Rz(-pi/2)*Ry(-pi/2+pi/4)*Rx(pi/2)
Rot4        =[cos(-pi/2) -sin(-pi/2) 0 0; sin(-pi/2) cos(-pi/2) 0 0; 0 0 1 0; 0 0 0 1]*...
             [cos(pi/2-pi/4) 0 sin(pi/2-pi/4) 0; 0 1 0 0; -sin(pi/2-pi/4) 0 cos(pi/2-pi/4) 0; 0 0 0 1]*...
             [1 0 0 0; 0 cos(-pi/2) -sin(-pi/2) 0 ;0 sin(-pi/2) cos(-pi/2) 0; 0 0 0 1]; %Rz(-pi/2)*Ry(pi/2-pi/4)*Rx(-pi/2)

gbs1        =Trasl1*Rot1;   %fixed transformation from b to s1
gbs2        =Trasl2*Rot2; 
gbs3        =Trasl3*Rot3;   %fixed transformation from b to s3
gbs4        =Trasl4*Rot4; 

gbs=[gbs1 gbs2 gbs3 gbs4];

% Motors
m_motori    =0.205+(2.156792741065949e-04)/4;                         %[Kg] da datasheet 77           
Lx_motori   =35.5e-3;sa
Ly_motori   =50.6e-3; 
Lz_motori   =35.5e-3;
Jx_motori   =(Ly_motori^2+Lz_motori^2)/12;
Jy_motori   =(Lx_motori^2+Lz_motori^2)/12;
Iz_motori   =(Lx_motori^2+Ly_motori ^2)/12;

M_motori0   =m_motori*diag([Jx_motori Jy_motori Iz_motori 1 1 1]);
Trasxb      =[1 0 0 -(Ls/2+Lx_motori/2+15e-3); 0 1 0 0; 0 0 1 0; 0 0 0 1];

gbm1        =gbs1*Trasxb;
gbm2        =gbs2*Trasxb;
gbm3        =gbs3*Trasxb;  % fixed transformation from b to m3 
gbm4        =gbs4*Trasxb; 

% 
% gbm1 = gx45*gz90*gbs1*gdx0075*gx90*Trasxb;
% gbm2 = gx45*gz90*gbs2*gdx0075*gx90*Trasxb;
% gbm3 = gx45*gz90*gbs3*gdx0075*gx90*Trasxb;
% gbm4 = gx45*gz90*gbs4*gdx0075*gx90*Trasxb;

m1          =dinamico_coAdjoint(gbm1)*M_motori0*dinamico_Adjoint(gbm1^-1);
m2          =dinamico_coAdjoint(gbm2)*M_motori0*dinamico_Adjoint(gbm2^-1);
m3          =dinamico_coAdjoint(gbm3)*M_motori0*dinamico_Adjoint(gbm3^-1);
m4          =dinamico_coAdjoint(gbm4)*M_motori0*dinamico_Adjoint(gbm4^-1);
M_motori    =m1+m2+m3+m4;

%total mass del body
Mb          =Mc + M_weight + M_motori; 
Mab         =Mb+Agb;                         %con added mass

% Massa spinta di Archimede (-ro_water per volume esterno)
MBuob           =zeros(6,6);
MBuob(4:6,4:6)  =(-rho_water)*Vc_e*diag([1;1;1]);

%%
Shell.n_l = 210;
Shell.n_r = 30;
Shell.r=@(X1)real(sqrt(2*0.09*X1*0.210-X1^2*0.210^2)*(1-heaviside(X1-3/7))+0.09*(heaviside(X1-3/7)-heaviside(X1-4/7))+sqrt(0.09^2-(X1-4/7)^2*0.210^2)*heaviside(X1-4/7));
Shell.M=Mb; %not nice, change density to 1000 and use the same bouyancy to make neutrally bouyant
Shell.gi=eye(4);
Shell.gf=eye(4);
Shell.color='b';

Shaft    = SorosimLink; %Rigid, Jointtype: R, Density: 2900, Length: 15e-3, Radius: 2.5e-3
Shaft.color='k';
Hook     = SorosimLink; %Soft, Fixed, Density: 1121, Eh: 1022610 Etah: 20, Rh: 12.5e-3, Lh: 50e-3
Hook.color='g';
Filament = SorosimLink; %Soft, Fixed, Density: 1121, Eh: 592949 Etah: 20, Rfbase: 12.5e-3, Rftip: 2e-3, Lh: 300e-3
Filament.color ='r'; 
Filament.n_l = 75; 

Rod = SorosimLink; %Rigid, Jointtype: R, Density: 2900, Length: 0.5, Radius: 0.03
Robot = SorosimLinkage(Shell,Shaft,Hook,Filament,Rod); %1+4*3+1 
