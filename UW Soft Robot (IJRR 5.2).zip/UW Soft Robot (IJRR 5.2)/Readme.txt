Step 1: Run startup.m
Step 2: Load files

For Legendre Basis
load('UWRobot_Leg.mat')

For Hybrid FEM Basis
load('UWRobot_FEM.mat')

Step 3: Run dynamic simulation

S1.dynamics([],'ode113')
Choose simulation time from the dialog box. Eg. 30s
In the next dialog box of Graphical Output choose No.

Step 4: Get video output
Choose yes to generate the video in the dialog box that appear when the simulation finish.
Alternatively:
load('DynamicsSolution.mat')
S1.plotqqd(t,qqd)