function B = B_CustomIndependent(X,varargin)
%To add a different custom base, make a file similar to this and change the file name of function handle in the corresponding Twist
%column of B should be linearly independent with others

dof = 9; % define dof here
B   = zeros(6,dof); % for linear basis Bq = B*q

% % example:kirchhoff beam with a quadratic FEM basis 1 element
% B(1,:) = [1-3*X+2*X^2, 4*X-4*X^2, -X+2*X^2,  zeros(1,6)];
% B(2,:) = [zeros(1,3), 1-3*X+2*X^2, 4*X-4*X^2, -X+2*X^2, zeros(1,3)];
% B(3,:) = [zeros(1,6), 1-3*X+2*X^2, 4*X-4*X^2, -X+2*X^2];

B = (X<0.5)*[0, 0, 0, 0, 0, 0;1, 0, 0, 0, 0, 0;0, 1, 0, 0, 0, 0; 0, 0, 1, 0, 0, 0;0, 0, 0, 0, 0, 0;0, 0, 0, 0, 0, 0]+(X>=0.5)*[0, 0, 0, 0, 0, 0;0, 0, 0, 1, 0, 0;0, 0, 0, 0, 1, 0;0, 0, 0, 0, 0, 1;0, 0, 0, 0, 0, 0;0, 0, 0, 0, 0, 0];
end