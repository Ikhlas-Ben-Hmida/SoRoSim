function [l1, l2, l3, l4] = Clength(t)


% load('centerq0_solnstaticsTip','theta','q')
% L1 = q(1,:); 
% L2 = q(2,:); 
% L3 = q(3,:); 
% L4 = q(4,:); 
% T = 30; %s30 econds%% best fit 0.001
% tv = theta*T/(2*pi);

% if t<T
%     l1 = interp1(tv,L1,t,'PCHIP');% l1 = interp1(tv,L1,t+T/4,'cubic');% +T/4 to start from pi/2
%     l2 = interp1(tv,L2,t,'PCHIP');
%     l3 = interp1(tv,L3,t,'PCHIP');
%     l4 = interp1(tv,L4,t,'PCHIP');
% else
%     l1 = L1(end);
%     l2 = L2(end);
%     l3 = L3(end);
%     l4 = L4(end);
% end
load('S1_rigidcable','l')

l1 = l;
l2 = l;
l3 = l;
l4 = l;
end