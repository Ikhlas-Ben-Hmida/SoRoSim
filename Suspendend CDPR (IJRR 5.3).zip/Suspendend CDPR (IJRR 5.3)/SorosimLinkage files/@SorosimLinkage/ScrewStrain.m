%Function that calculates the screw velocity (eta) at every significant point
%(24.05.2021)
function xi = ScrewStrain(Tr,q,t)
if nargin==2
    t=0;
end
if isrow(q)
    q=q';
end

N         = Tr.N;
nsig      = Tr.nsig;

%% Mass, Corriolis, Gravity
for i=1:N
    if Tr.VLinks(Tr.LinkIndex(i)).jointtype=='U' %two strain values must be saved for a universal joint.
        nsig = nsig+1; 
    end
end

xi        = zeros(6*nsig,1);
dof_start = 1; %starting dof of current piece
i_sig     = 1;

for i = 1:N
    
    %Joint
    dof_here = Tr.CVTwists{i}(1).dof;
    q_here   = q(dof_start:dof_start+dof_here-1);
    B_here   = Tr.CVTwists{i}(1).B;
    xi_star  = Tr.CVTwists{i}(1).xi_star;
    
    if dof_here == 0 %fixed joint (N)
        xi((i_sig-1)*6+1:i_sig*6) = zeros(6,1);
        i_sig                     = i_sig+1;
    else

        xi_here                   = B_here*q_here+xi_star;
        xi((i_sig-1)*6+1:i_sig*6) = xi_here;
        i_sig                     = i_sig+1;

    end
    
    if Tr.VLinks(Tr.LinkIndex(i)).linktype == 'r'
        
        xi((i_sig-1)*6+1:i_sig*6) = zeros(6,1); % doesnt have a meaning
        i_sig                     = i_sig+1;

    end
    
    dof_start = dof_start+dof_here;
    
    for j = 1:Tr.VLinks(Tr.LinkIndex(i)).npie-1
        
        dof_here = Tr.CVTwists{i}(j+1).dof;
        q_here   = q(dof_start:dof_start+dof_here-1);
        xi_star  = Tr.CVTwists{i}(j+1).xi_star;
        Lscale   = Tr.VLinks(Tr.LinkIndex(i)).lp{j};
        
        Xs       = Tr.CVTwists{i}(j+1).Xs;
        nip      = Tr.CVTwists{i}(j+1).nip;
        
        if ~any(strcmp(Tr.CVTwists{i}(j+1).Type,{'Custom Dependent (q)','Custom Dependent (t)','Custom Dependent (q,t)'}))
            B       = Tr.CVTwists{i}(j+1).B;
        else
            Bh = Tr.CVTwists{i}(j+1).Bh;
        end 
        
        for ii = 1:nip
            
             xi_here = xi_star(6*(ii-1)+1:6*ii,1);

            if strcmp(Tr.CVTwists{i}(j+1).Type,'Custom Dependent (q,t)')
                X_Z = Xs(ii-1)+H*Z;
                Bq_here = Bh(X_Z,q_here,t);
                xi_here  = xi_here+Bq_here;
            elseif strcmp(Tr.CVTwists{i}(j+1).Type,'Custom Dependent (q)')
                X_Z = Xs(ii-1)+H*Z;
                Bq_here = Bh(X_Z,q_here);
                xi_here  = xi_here+Bq_here;
            elseif strcmp(Tr.CVTwists{i}(j+1).Type,'Custom Dependent (t)')
                X_Z = Xs(ii-1)+H*Z;
                B_here = Bh(X_Z,t);
                xi_here = B_here*q_here+xi_here;
            else
                B_here  = B(6*(ii-1)+1:6*ii,:);%note this step
                if dof_here>0
                    xi_here = B_here*q_here+xi_here; 
                end
            end
            xi_here(1:3) = xi_here(1:3)/Lscale; %Lscale
            xi((i_sig-1)*6+1:i_sig*6) = xi_here;
            i_sig                     = i_sig+1;
            
        end
        
        dof_start  = dof_start+dof_here;
    end
    
end
end

