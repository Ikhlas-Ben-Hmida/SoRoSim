%Computes the generalized stiffness matrix for the linkage
%Last modified by Anup Teejo Mathew 02.03.2022
function K = findK(Tr,varargin)

if nargin==3
    q=varargin{1};
    t=varargin{2};
else
    q=zeros(Tr.ndof,1);
    t=0;
end

CK = cell(Tr.N,1);

dof_start = 1;
for i=1:Tr.N
    
    CK{i}   = cell(Tr.VLinks(Tr.LinkIndex(i)).npie,1);
    VTwists = Tr.CVTwists{i};

    if Tr.VLinks(Tr.LinkIndex(i)).Kj==0
        CK{i}{1} = zeros(VTwists(1).dof);
    else
        if isequal(size(Tr.VLinks(Tr.LinkIndex(i)).Kj),[VTwists(1).dof,VTwists(1).dof])
            CK{i}{1} = Tr.VLinks(Tr.LinkIndex(i)).Kj;
        else
            uiwait(msgbox('Incorrect joint stiffness matrix dimensions','Error','error'));
            return
        end
    end
    
    dof_start = dof_start+VTwists(1).dof;  
    for j=1:(Tr.VLinks(Tr.LinkIndex(i)).npie)-1 %for the rest of soft link divisions
        
        ld       = Tr.VLinks(Tr.LinkIndex(i)).lp{j};
        Es       = VTwists(j+1).Es;
        dof_here = VTwists(j+1).dof;
        Ws       = VTwists(j+1).Ws;
        nip       = VTwists(j+1).nip;
        Xs       = VTwists(j+1).Xs;
        
        if ~(strcmp(VTwists(j+1).Type,'Custom Dependent (q,t)')||strcmp(VTwists(j+1).Type,'Custom Dependent (q)')||strcmp(VTwists(j+1).Type,'Custom Dependent (t)'))
            dBqdq = VTwists(j+1).B;
        else
            Bh = VTwists(j+1).Bh; 
            dBqdq = zeros(6*nip,dof_here);
            for ii=2:nip-1
                if strcmp(VTwists(j+1).Type,'Custom Dependent (q,t)')
                    q_here = q(dof_start:dof_start+dof_here-1); 
                    [~,dBqdq_here] = Bh(Xs(ii),q_here,t);
                elseif strcmp(VTwists(j+1).Type,'Custom Dependent (q)')
                    q_here = q(dof_start:dof_start+dof_here-1); 
                    [~,dBqdq_here] = Bh(Xs(ii),q_here);
                else
                    dBqdq_here = Bh(Xs(ii),t);
                end
                dBqdq((ii-1)*6+1:ii*6,:) = dBqdq_here;
            end
        end

        Ktemp  = zeros(dof_here,dof_here);
        
        %scaling of quantities
        Lscale        = ld;
        
        for ii=2:nip-1
            if Ws(ii)>0
                Es_here = Es((ii-1)*6+1:ii*6,:);
                %scaling
                Es_here(1:3,:) = Es_here(1:3,:)/Lscale^3;
                Es_here(4:6,:) = Es_here(4:6,:)/Lscale;

                Ktemp = Ktemp+Ws(ii)*dBqdq((ii-1)*6+1:ii*6,:)'*Es_here*dBqdq((ii-1)*6+1:ii*6,:);
            end
        end
        
        CK{i}{j+1} = Ktemp*Lscale^2; %scaling back 
        dof_start  = dof_start+dof_here;
    end
    
end

%construct K matrix:
K = [];
for i=1:Tr.N
    for j=1:Tr.VLinks(Tr.LinkIndex(i)).npie
        K = blkdiag(K,CK{i}{j});
    end
end

% q_scale = find_q_scale(Tr);
% % K       = K./(q_scale*q_scale'); %actual K
end