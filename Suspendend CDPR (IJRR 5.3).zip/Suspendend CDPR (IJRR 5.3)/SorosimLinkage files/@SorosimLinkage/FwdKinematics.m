%Function that calculates the forward kinematics of the linkage from the base to the linkage tip at every significant points(24.05.2021)
%Last modified by Anup Teejo Mathew 02.03.2022
function g = FwdKinematics(Tr,q,t)
if nargin==2
    t=0;
end
if isrow(q)
    q=q';
end

N         = Tr.N;
nsig      = Tr.nsig;
g_ini     = Tr.g_ini;
g_Ltip    = repmat(eye(4),N,1);
iLpre     = Tr.iLpre;

g         = zeros(4*nsig,4);
dof_start = 1;                         %starting dof of current piece
i_sig     = 1;

for i = 1:N
    
    if Tr.iLpre(i)>0
        g_here=g_Ltip((iLpre(i)-1)*4+1:iLpre(i)*4,:)*g_ini((i-1)*4+1:i*4,:);
    else
        g_here=g_ini((i-1)*4+1:i*4,:);
    end
    
    %Joint
    dof_here = Tr.CVTwists{i}(1).dof;
    q_here   = q(dof_start:dof_start+dof_here-1);
    B_here   = Tr.CVTwists{i}(1).B;
    xi_star  = Tr.CVTwists{i}(1).xi_star;
    
    if dof_here == 0                   %fixed joint (N)
        g_joint  = eye(4);
    else
        if Tr.VLinks(Tr.LinkIndex(i)).jointtype=='U'  %special case for universal joint. Considered as 2 revolute joints
            % first revolute joint
            xi      = B_here(:,1)*q_here(1)+xi_star;
            g_joint = variable_expmap_g(xi);
            g_here  = g_here*g_joint;
            % second revolute joint
            xi      = B_here(:,2)*q_here(2)+xi_star;
            g_joint = variable_expmap_g(xi);
        else
            xi      = B_here*q_here+xi_star;
            g_joint = variable_expmap_g(xi);
        end
    end

    g_here                     = g_here*g_joint;
    g((i_sig-1)*4+1:i_sig*4,:) = g_here;
    i_sig                      = i_sig+1;
    
    if Tr.VLinks(Tr.LinkIndex(i)).linktype == 'r'
        
        gi                         = Tr.VLinks(Tr.LinkIndex(i)).gi;
        g_here                     = g_here*gi;
        g((i_sig-1)*4+1:i_sig*4,:) = g_here;
        i_sig                      = i_sig+1;
        % bringing all quantities to the end of rigid link
        gf     = Tr.VLinks(Tr.LinkIndex(i)).gf;
        g_here = g_here*gf;
    end
    
    dof_start = dof_start+dof_here;
    
    for j = 1:Tr.VLinks(Tr.LinkIndex(i)).npie-1
        
        dof_here = Tr.CVTwists{i}(j+1).dof;
        q_here   = q(dof_start:dof_start+dof_here-1);
        xi_star  = Tr.CVTwists{i}(j+1).xi_star;
        gi       = Tr.VLinks(Tr.LinkIndex(i)).gi{j};
        lpf      = Tr.VLinks(Tr.LinkIndex(i)).lp{j};
        Xs       = Tr.CVTwists{i}(j+1).Xs;
        nip      = Tr.CVTwists{i}(j+1).nip;
        
        if ~any(strcmp(Tr.CVTwists{i}(j+1).Type,{'Custom Dependent (q)','Custom Dependent (t)','Custom Dependent (q,t)'}))
            if Tr.Z_order==4
                B_Z1       = Tr.CVTwists{i}(j+1).B_Z1;
                B_Z2       = Tr.CVTwists{i}(j+1).B_Z2;
            else %order 2
                B_Z        = Tr.CVTwists{i}(j+1).B_Z;
            end
        else
            Bh = Tr.CVTwists{i}(j+1).Bh;
        end
        
        %updating g, Jacobian, Jacobian_dot and eta at X=0
        g_here                     = g_here*gi;
        
        g((i_sig-1)*4+1:i_sig*4,:) = g_here;
        i_sig                      = i_sig+1;
        
        Lscale         = lpf; 
        
        for ii = 2:nip

            H    = Xs(ii)-Xs(ii-1);
            
            if Tr.Z_order==4
                
                xi_Z1here = xi_star(6*(ii-2)+1:6*(ii-1),2); %already scaled properly by user
                xi_Z2here = xi_star(6*(ii-2)+1:6*(ii-1),3);
                if dof_here>0
                    if strcmp(Tr.CVTwists{i}(j+1).Type,'Custom Dependent (q,t)')
                        X_Z1 = Xs(ii-1)+H*Z1;
                        X_Z2 = Xs(ii-1)+H*Z2;
                        Bq_Z1here = Bh(X_Z1,q_here,t);
                        Bq_Z2here = Bh(X_Z2,q_here,t);
                        xi_Z1here  = xi_Z1here+Bq_Z1here;
                        xi_Z2here  = xi_Z2here+Bq_Z2here;
                    elseif strcmp(Tr.CVTwists{i}(j+1).Type,'Custom Dependent (q)')
                        X_Z1 = Xs(ii-1)+H*Z1;
                        X_Z2 = Xs(ii-1)+H*Z2;
                        Bq_Z1here = Bh(X_Z1,q_here);
                        Bq_Z2here = Bh(X_Z2,q_here);
                        xi_Z1here  = xi_Z1here+Bq_Z1here;
                        xi_Z2here  = xi_Z2here+Bq_Z2here;
                    elseif strcmp(Tr.CVTwists{i}(j+1).Type,'Custom Dependent (t)')
                        X_Z1 = Xs(ii-1)+H*Z1;
                        X_Z2 = Xs(ii-1)+H*Z2;
                        [B_Z1here,~,~,xit_Z1here] = Bh(X_Z1,t);
                        [B_Z2here,~,~,xit_Z2here] = Bh(X_Z2,t);
                        xi_Z1here  = B_Z1here*q_here+xit_Z1here+xi_Z1here;
                        xi_Z2here  = B_Z2here*q_here+xit_Z2here+xi_Z2here;
                    else
                        B_Z1here  = B_Z1(6*(ii-2)+1:6*(ii-1),:);%note this step
                        B_Z2here  = B_Z2(6*(ii-2)+1:6*(ii-1),:);
                        if dof_here>0
                            xi_Z1here = B_Z1here*q_here+xi_Z1here;
                            xi_Z2here = B_Z2here*q_here+xi_Z2here;
                        end
                    end
                end
                ad_xi_Z1here = dinamico_adj(xi_Z1here);  
                Gamma_here   = (H/2)*(xi_Z1here+xi_Z2here)+...
                                ((sqrt(3)*H^2)/12)*ad_xi_Z1here*xi_Z2here;
                      
            else % order 2
                xi_Zhere = xi_star(6*(ii-2)+1:6*(ii-1),4);
                if dof_here>0
                    if strcmp(Tr.CVTwists{i}(j+1).Type,'Custom Dependent (q,t)')
                        X_Z = Xs(ii-1)+H*Z;
                        Bq_Zhere = Bh(X_Z,q_here,t);
                        xi_Zhere  = xi_Zhere+Bq_Zhere;
                    elseif strcmp(Tr.CVTwists{i}(j+1).Type,'Custom Dependent (q)')
                        X_Z = Xs(ii-1)+H*Z;
                        Bq_Zhere = Bh(X_Z,q_here);
                        xi_Zhere  = xi_Zhere+Bq_Zhere;
                    elseif strcmp(Tr.CVTwists{i}(j+1).Type,'Custom Dependent (t)')
                        X_Z = Xs(ii-1)+H*Z;
                        [B_Zhere,~,~,xit_Zhere] = Bh(X_Z,t);
                        xi_Zhere = B_Zhere*q_here+xit_Zhere+xi_Zhere;
                    else
                        B_Zhere  = B_Z(6*(ii-2)+1:6*(ii-1),:);%note this step
                        if dof_here>0
                            xi_Zhere = B_Zhere*q_here+xi_Zhere;
                        end
                    end
                end
                
                Gamma_here  = H*xi_Zhere;

            end
            Gamma_here(4:6) = Gamma_here(4:6)*Lscale;
            gh              = variable_expmap_g(Gamma_here);

            %updating g, Jacobian, Jacobian_dot and eta
            
            g_here                     = g_here*gh;
            g((i_sig-1)*4+1:i_sig*4,:) = g_here;
            i_sig                      = i_sig+1;

        end

        gf        = Tr.VLinks(Tr.LinkIndex(i)).gf{j};
        g_here    = g_here*gf;
        dof_start = dof_start+dof_here;
        
    end
    g_Ltip((i-1)*4+1:i*4,:) = g_here; 
end

end


