/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * _coder_variable_expmap_gTgTgd_info.h
 *
 * Code generation for function '_coder_variable_expmap_gTgTgd_info'
 *
 */

#pragma once

/* Include files */
#include "mex.h"

/* Function Declarations */
MEXFUNCTION_LINKAGE mxArray *emlrtMexFcnProperties(void);

/* End of code generation (_coder_variable_expmap_gTgTgd_info.h) */
