%Function to calculate the custom external force
%Last modified by Anup Teejo Mathew 30/06/2021

function Fext=CustomExtForce(Tr,q,g,J,t,qd,eta,Jdot)
% eta = J*qd;
%%%%NOTE%%%%
%Tr: Linkage element,
%q and qd: joint coordinates and their time derivatives,
%g, J, Jd, and eta: transformation matrix, Jacobian, time derivative of jacobian, and screw velocity at every significant point of the linkage
%t:  time

%Fext should be 6*n column vector where n is the total number of gaussian points of all soft links (nGauss) + number of rigid links.
%(Example: linkage with 2 soft links and 1 rigid link (n=nGauss1+nGauss2+1)
%Fext should be arranged according to the order of precedence
%Fext should be distributed force for a soft link and point force for a rigid link

% Significant points: 1 for every joint, 1 at the center of the rigid link, 1 at the start and end of every soft link and 1 for each Gaussian points

% J   = S.Jacobian(q);         %geometric jacobian of the linkage calculated at every significant points
% g   = S.FwdKinematics(q);    %transformation matrix of the linkage calculated at every significant points
% eta = S.ScrewVelocity(q,qd); %Screwvelocity of the linkage calculated at every significant points
% J   = S.Jacobiandot(q,qd);   %time derivative of geometric jacobian of the linkage calculated at every significant points


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% CUSTOM EXTERNAL FORCE, tentacle problem
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


Rho_water    = 1000;
i_sig    = 1;
i_sig_nj = 1;
DL     = Tr.CP1;
% t = 0;
% tf=5;
% Xe = 0.25+t/2/tf;                          % Center applied force
% Xe = t/tf;                          % Center applied force
% Xe = 0.5;                          % Center applied force
% b  = 1/10;


%filament
i_sig    = i_sig+1;%joint


Xs = Tr.CVTwists{1}(2).Xs;
% Ws = Tr.CVTwists{1}(2).Ws;
nGauss        = length(Xs);
Fext          = zeros(6*nGauss,1);
% Fext2         = zeros(6*nGauss,1);
% F             = zeros(1,length(Xs));
% FF            = zeros(1,length(Xs));
% Strain        = zeros(1,length(Xs));

i_sig    = i_sig+1;
i_sig_nj = i_sig_nj+1;
% k_force = 4;
% E = 1e6;
% r = 0.015;
% Jy = (pi/4)*(r^4);

% suma = k_force*b/2/(E*Jy);
rho_filament  = Tr.VLinks(1).Rho;
M_filament    = Tr.CVTwists{1}(2).Ms;
G =Tr.G;

for i=2:nGauss-1

%     if(Xs(i)>=Xe-b/2 && Xs(i)<=Xe+b/2)
%         F(i) = k_force*(1-abs(Xe-Xs(i))/(b/2));
%     else
%         F(i) = 0;
%     end

%     Fl_ext = [0;F(i)-t/tf/2*F(i);F(i)+t/tf/2*F(i);0;0;0];
%     Fl_ext = [0;F(i)+t/tf/2*F(i);0;0;0;0];
%     Fl_ext = [0;F(i);0;0;0;0];
    
%     FF(i) = F(i)/(E*Jy);
%     suma = suma - Ws(i)*FF(i);
%     Strain(i)= suma; 

    g_here                    = g((i_sig-1)*4+1:i_sig*4,:);
%     Fext((i-1)*6+1:i*6)       = dinamico_coAdjoint(ginv(g_here))*Fl_ext;     % Global forces
%     Fext((i-1)*6+1:i*6)       = Fl_ext;                                        % Local forces
    
%filament

    


        M_here                    = M_filament((i-1)*6+1:i*6,:);
        eta_here                  = eta((i_sig-1)*6+1:i_sig*6);
        DL_here                   = DL((i_sig_nj-1)*6+1:i_sig_nj*6,:);
        Fext((i-1)*6+1:i*6)      = -Rho_water/rho_filament*M_here*dinamico_Adjoint(ginv(g_here))*G-DL_here*norm(eta_here(4:6))*eta_here;%-rho_water/rho_filament



%     J_here'*dinamico_Adjoint(inv(g_here))*Mass*Gra*K_Gra;

    i_sig    = i_sig+1;
    i_sig_nj = i_sig_nj+1;
end

% axes1 = axes('FontSize',30);box(axes1,'on');hold(axes1,'on');
% plot(Xs,Strain*0.8,'LineWidth',2);hold on;
% xlabel('X');ylabel('\xi_{2}');
% a=2
end