clc;
clear all;
close all;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% syms q1 q2 q3 X qd1 qd2 qd3
% y = q1*(exp(-q2*(X-q3))./(1+exp(-q2*(X-q3))));
% dy_q1 = diff(y,q1)
% pretty(dy_q1)
% dy_q2 = diff(y,q2)
% pretty(dy_q2)
% dy_q3 = diff(y,q3)
% pretty(dy_q3)
% 
% dy = dy_q1*qd1 + dy_q2*qd2 + dy_q3*qd3
% 
% dyy_qq1 = diff(dy,q1)
% pretty(dyy_qq1)
% dyy_qq2 = diff(dy,q2)
% pretty(dyy_qq2)
% dyy_qq3 = diff(dy,q3)
% pretty(dyy_qq3)


% syms q1 q2 t tf X qd1 qd2
% y = q1*exp(-q2^2*(X - t/tf)^2); %gaussian dependent (q,t)
% dy_q1 = diff(y,q1)
% dy_q2 = diff(y,q2)
% dy_dt = diff(y,t)
% 
% dy = dy_q1*qd1 + dy_q2*qd2;
% 
% dyy_qq1 = diff(dy,q1)
% dyy_qq2 = diff(dy,q2)
% dyy_ddt = diff(dy_dt,t)
% dy_q1_dt = diff(dy_q1,t)
% dy_q2_dt = diff(dy_q2,t)

% Octopus strain

syms q1 q2 q3 X qd1 qd2 qd3
y = q1/(1+(q2*(X-q3))^2);
dy_q1 = diff(y,q1)
dy_q2 = diff(y,q2)
dy_q3 = diff(y,q3)

dy = dy_q1*qd1 + dy_q2*qd2 + dy_q3*qd3

dyy_qq1 = diff(dy,q1)
dyy_qq2 = diff(dy,q2)
dyy_qq3 = diff(dy,q3)