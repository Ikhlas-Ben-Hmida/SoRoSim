function [B,dBdt,d2Bd2t,xit,dxitdt,d2xitd2t] = B_CustomTDependent(X,varargin)
%Add more and change file name in twist if needed
%Bq should be linearly independent with others
%linear with q
%xi = B(X,t)*q+xit(X,t)+xi_star

if isempty(varargin)
    t = 0;
else
    t = varargin{1};
end

dof = 2; % define dof here
B      = zeros(6,dof);
dBdt   = zeros(6,dof);
d2Bd2t = zeros(6,dof);
xit    = zeros(6,1);
dxitdt = zeros(6,1);
d2xitd2t = zeros(6,1);
%Inverse Quadratic 2 dof

B(2,1) = 1*cos(2*pi*t/5); B(2,2) = X*cos(2*pi*t/5);
B(3,1) = 1*sin(2*pi*t/5); B(3,2) = X*sin(2*pi*t/5);

dBdt(2,1) = -2*pi/5*(1)*sin(2*pi*t/5); dBdt(2,2) = -2*pi/5*(X)*sin(2*pi*t/5);
dBdt(3,1) = 2*pi/5*(1)*cos(2*pi*t/5); dBdt(3,2) = 2*pi/5*(X)*cos(2*pi*t/5);

d2Bd2t(2,1) = -(2*pi/5)^2*(1)*cos(2*pi*t/5); d2Bd2t(2,2) = -(2*pi/5)^2*(X)*cos(2*pi*t/5);
d2Bd2t(3,1) = -(2*pi/5)^2*(1)*sin(2*pi*t/5); d2Bd2t(3,2) = -(2*pi/5)^2*(X)*sin(2*pi*t/5);

end