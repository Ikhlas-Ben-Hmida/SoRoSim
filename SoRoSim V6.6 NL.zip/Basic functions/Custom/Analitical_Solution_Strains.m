
Xe = 0.5;                          % Center applied force
b  = 1/10;

Xs = [0:0.001:1];
Ws = [0.001/2 0.001*ones(1,999) 0.001/2];

% Xe = 0.4;                          % Center applied force
% b  = 1/10*0.8;
% h = 0.001;
% Xs = [0:h:0.8];
% Ws = [0.01/2 0.01*ones(1,99) 0.01/2];

n = length(Xs);
F             = zeros(1,length(Xs));
FF            = zeros(1,length(Xs));
Strain        = zeros(1,length(Xs));
k_force = 1;
E = 1e6;
r = 0.015;
Jy = (pi/4)*(r^4); 

suma = k_force*b/2/(E*Jy);

for i=1:n

    if(Xs(i)>=Xe-b/2 && Xs(i)<=Xe+b/2)
        F(i) = 1-abs(Xe-Xs(i))/(b/2);
    else
        F(i) = 0;
    end

    F(i) = k_force*F(i);
    FF(i) = F(i)/(E*Jy);

    suma = suma - Ws(i)*FF(i);

    Strain(i)= suma; 
end

axes1 = axes('FontSize',30);box(axes1,'on');hold(axes1,'on');
plot(Xs,Strain*0.8,'LineWidth',2);hold on;
xlabel('X');ylabel('\xi_{2}');
