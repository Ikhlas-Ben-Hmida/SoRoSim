clc;
clear all;
close all;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

q1 = 1;
q2 = 10;
X = [0:0.001:1];
t = 0.1;

strain = q1*exp(-q2^2*(X - t/5).^2);
plot(X,strain);