This folder contains several functions that are used for vector/matrix 
manipulation, mapping from one space to another as well as calculating the
tangent operator 
