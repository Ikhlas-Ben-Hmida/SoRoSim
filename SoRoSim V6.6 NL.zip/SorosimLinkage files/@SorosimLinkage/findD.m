%Computes the generalized damping matrix for the linkage
%Last modified by Anup Teejo Mathew 02.03.2022
function D = findD(Tr,varargin)

if nargin==4
    q  = varargin{1};
    qd = varargin{2};
    t  = varargin{3};
else
    q  = zeros(Tr.ndof,1);
    qd = zeros(Tr.ndof,1);
    t  = 0;
end

dof_start = 1;

if ~Tr.dependent %typical case
    D = zeros(Tr.ndof,Tr.ndof); %NxN matrix 
    for i=1:Tr.N

        VTwists = Tr.CVTwists{i};
        dof_here = VTwists(1).dof;
        %for joint (rigid link)
        if Tr.VLinks(Tr.LinkIndex(i)).Dj==0
            D(dof_start:dof_start+dof_here-1,dof_start:dof_start+dof_here-1) = zeros(VTwists(1).dof);
        else
            if isequal(size(Tr.VLinks(Tr.LinkIndex(i)).Kj),[VTwists(1).dof,VTwists(1).dof])
                D(dof_start:dof_start+dof_here-1,dof_start:dof_start+dof_here-1) = Tr.VLinks(Tr.LinkIndex(i)).Dj;
            else
                uiwait(msgbox('Incorrect joint damping matrix dimensions','Error','error'));
                return
            end
        end
        dof_start = dof_start+dof_here;
        for j=1:(Tr.VLinks(Tr.LinkIndex(i)).npie)-1 %for the rest of soft pieces

            ld       = Tr.VLinks(Tr.LinkIndex(i)).lp{j};
            Gs       = VTwists(j+1).Gs;
            dof_here = VTwists(j+1).dof;
            Ws       = VTwists(j+1).Ws;
            nip       = VTwists(j+1).nip;

            Dtemp  = zeros(dof_here,dof_here);

            %scaling of quantities
            Lscale = ld;
            dBqdq  = VTwists(j+1).B;

            for ii=2:nip-1
                if Ws(ii)>0
                    Gs_here = Gs((ii-1)*6+1:ii*6,:);
                    %scaling
                    Gs_here(1:3,:) = Gs_here(1:3,:)/Lscale^3;
                    Gs_here(4:6,:) = Gs_here(4:6,:)/Lscale;

                    Dtemp = Dtemp+Ws(ii)*dBqdq((ii-1)*6+1:ii*6,:)'*Gs_here*dBqdq((ii-1)*6+1:ii*6,:);
                end
            end

            D(dof_start:dof_start+dof_here-1,dof_start:dof_start+dof_here-1) = Dtemp*Lscale^2; %scaling back 
            dof_start  = dof_start+dof_here;
        end
    end
else
     D = zeros(Tr.ndof,1);
     for i=1:Tr.N
 
        VTwists = Tr.CVTwists{i};
        dof_here = VTwists(1).dof;
        %for joint (rigid link)
        if Tr.VLinks(Tr.LinkIndex(i)).Dj==0
            D(dof_start:dof_start+dof_here-1) = zeros(VTwists(1).dof,1);
        else
            if isequal(size(Tr.VLinks(Tr.LinkIndex(i)).Kj),[VTwists(1).dof,VTwists(1).dof])
                qd_here = qd(dof_start:dof_start+dof_here-1);
                D(dof_start:dof_start+dof_here-1) = Tr.VLinks(Tr.LinkIndex(i)).Dj*qd_here;
            else
                uiwait(msgbox('Incorrect joint damping matrix dimensions','Error','error'));
                return
            end
        end
        dof_start = dof_start+dof_here;
        for j=1:(Tr.VLinks(Tr.LinkIndex(i)).npie)-1 %for the rest of soft pieces

            ld       = Tr.VLinks(Tr.LinkIndex(i)).lp{j};
            Gs       = VTwists(j+1).Gs;
            dof_here = VTwists(j+1).dof;
            Ws       = VTwists(j+1).Ws;
            nip       = VTwists(j+1).nip;
            Xs       = VTwists(j+1).Xs;

            Dtemp  = zeros(dof_here,1);

            %scaling of quantities
            Lscale        = ld;
            
            Bh = VTwists(j+1).Bh;

            for ii=2:nip-1
                if Ws(ii)>0
                    qd_here = qd(dof_start:dof_start+dof_here-1);
                    q_here = q(dof_start:dof_start+dof_here-1);
                    if strcmp(VTwists(j+1).Type,'Custom Dependent (q,t)')
                        [~,dBqdq_here,dBqdt_here] = Bh(Xs(ii),q_here,t);
                        xid_here = dBqdq_here*qd_here+dBqdt_here;
                    elseif strcmp(VTwists(j+1).Type,'Custom Dependent (q)')
                        q_here = q(dof_start:dof_start+dof_here-1); 
                        [~,dBqdq_here] = Bh(Xs(ii),q_here);
                        xid_here = dBqdq_here*qd_here;
                    elseif strcmp(VTwists(j+1).Type,'Custom Dependent (t)')
                        [dBqdq_here,dBdt_here,~,~,dxitdt_here] = Bh(Xs(ii),t);
                        xid_here = dBqdq_here*qd_here+dBdt_here*q_here+dxitdt_here;
                    else
                        dBqdq_here = VTwists(j+1).B((ii-1)*6+1:ii*6,:);
                        xid_here = dBqdq_here*qd_here;
                    end
                    Gs_here = Gs((ii-1)*6+1:ii*6,:);
                    %scaling
                    Gs_here(1:3,:) = Gs_here(1:3,:)/Lscale^3;
                    Gs_here(4:6,:) = Gs_here(4:6,:)/Lscale;

                    Dtemp = Dtemp+Ws(ii)*dBqdq_here'*Gs_here*xid_here;
                end
            end

            D(dof_start:dof_start+dof_here-1) = Dtemp*Lscale^2;
            dof_start  = dof_start+dof_here;
        end
    end
end


end
