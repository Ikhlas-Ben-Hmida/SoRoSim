Tutorial to simulate the arm octopus scenario

S_P3_2.mat has the linkage to simulate dependent bases + monomial bases 
SP3_FEM_10_Cubic.mat for Cubic FEM basis with 10 elements

1. Open startup.m and run this file
2. Load S_P3_2.mat or SP3_FEM_10_Cubicmat depending on the case.
3. Run S_P3_2.dynamics or SP3_FEM_10_Cubic.dynamics
4. Introduce value of q0, qdot0 and simulation time.
The initial guesses q0 of the paper simulations are:
S_P3_2 = [-14.5 10.7 0.5 0 0 0];
SP3_FEM_10_Cubic = [-0.4921 -0.5621 -0.6479 -0.7543 -0.8892 -1.0622 -1.2890 -1.5939 -2.0152 -2.6045 -3.4858 -4.7917 -6.8246 -9.6481 -12.8874 -14.5724 -12.8893 -9.6456 -6.8313 -4.7885 -3.4891 -2.5987 -2.0165 -1.5929 -1.2910 -1.0618 -0.8895 -0.7537 -0.6481 -0.5619 -0.4926];

The simulatio time is 2s.


