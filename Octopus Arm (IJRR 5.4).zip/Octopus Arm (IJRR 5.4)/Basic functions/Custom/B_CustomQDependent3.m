function [Bq,dBqdq,d2Bqdqdq_qd] = B_CustomQDependent(X,varargin)
%Add more and change file name in twist if needed
%Bq should be linearly independent with others
Bq    = zeros(6,1); % for linear basis Bq = B(X,q)

dof = 4; % define dof here
dBqdq = zeros(6,dof);
d2Bqdqdq_qd = zeros(6,dof);
if nargin==1
    q  = zeros(dof,1);
    qd = zeros(dof,1);
elseif nargin==2
    q  = varargin{1};
    qd = zeros(dof,1);
elseif nargin==3
    q  = varargin{1};
    qd = varargin{2};
end

q1 = q(1);
q2  = q(2);
qd1 = qd(1);
qd2  = qd(2);
q3 = q(3);
q4  = q(4);
qd3 = qd(3);
qd4  = qd(4);
t = 2.5;
tf = 5;

Bq(2) = q1*exp(-q2^2*(X - t/tf)^2); %gaussian dependent (q,t)
Bq(3) = q3*exp(-q4^2*(X - t/tf)^2); %gaussian dependent (q,t)


dBqdq(2,1) = exp(-q2^2*(X - t/tf)^2);
dBqdq(2,2) = -2*q1*q2*exp(-q2^2*(X - t/tf)^2)*(X - t/tf)^2;
dBqdq(3,3) = exp(-q4^2*(X - t/tf)^2);
dBqdq(3,4) = -2*q3*q4*exp(-q4^2*(X - t/tf)^2)*(X - t/tf)^2;

d2Bqdqdq_qd(2,1) = -2*q2*(X - t/tf)^2*exp(-q2^2*(X - t/tf)^2)*qd2;
d2Bqdqdq_qd(2,2) = -2*q2*(X - t/tf)^2*exp(-q2^2*(X - t/tf)^2)*qd1+(4*q1*q2^2*(X - t/tf)^4*exp(-q2^2*(X - t/tf)^2) - 2*q1*(X - t/tf)^2*exp(-q2^2*(X - t/tf)^2))*qd2;
d2Bqdqdq_qd(3,3) = -2*q4*(X - t/tf)^2*exp(-q4^2*(X - t/tf)^2)*qd4;
d2Bqdqdq_qd(3,4) = -2*q4*(X - t/tf)^2*exp(-q4^2*(X - t/tf)^2)*qd3+(4*q3*q4^2*(X - t/tf)^4*exp(-q4^2*(X - t/tf)^2) - 2*q3*(X - t/tf)^2*exp(-q4^2*(X - t/tf)^2))*qd4;



end