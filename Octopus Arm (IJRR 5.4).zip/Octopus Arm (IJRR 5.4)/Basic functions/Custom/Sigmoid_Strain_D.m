clc;
clear all;
close all;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

q1 = 1;
q2 = 50;
q3 = 0.5;

X = [0:0.001:1];
t = 0.1;

strain = q1*(1-1./(1+exp(-q2*(X-q3))));
strain = q1*(exp(-q2*(X-q3))./(1+exp(-q2*(X-q3))));
plot(X,strain);