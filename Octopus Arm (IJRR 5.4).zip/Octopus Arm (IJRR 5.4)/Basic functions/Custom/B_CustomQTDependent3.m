function [Bq,dBqdq,dBqdt,d2Bqdqdq_qd,d2Bqdqdt,d2Bqd2t] = B_CustomQTDependent(X,varargin)%q,t,qd
%Add more and change file name in twist if needed
%Bq should be linearly independent with others

Bq    = zeros(6,1); % for linear basis Bq = B*q
dof   = 10; % define dof here
dBqdq = zeros(6,dof);
dBqdt = zeros(6,1);
d2Bqdqdq_qd = zeros(6,dof);
d2Bqdqdt    = zeros(6,dof);
d2Bqd2t     = zeros(6,1);
if nargin==1
    q  = zeros(dof,1);
    t  = 0;
    qd = zeros(dof,1);
elseif nargin==2
    q  = varargin{1};
    t  = 0;
    qd = zeros(dof,1);
elseif nargin==3
    q  = varargin{1};
    t  = varargin{2};
    qd = zeros(dof,1);
elseif nargin==4
    q  = varargin{1};
    t  = varargin{2};
    qd = varargin{3};
end


%Inverse Quadratic 2 dof

q1 = q(1);
q2  = q(2);
q3 = q(3);
q4  = q(4);
q5 = q(5);
qd1 = qd(1);
qd2  = qd(2);
qd3 = qd(3);
qd4  = qd(4);
qd5 = qd(5);
q6 = q(6);
q7  = q(7);
q8 = q(8);
q9  = q(9);
q10 = q(10);
qd6 = qd(6);
qd7  = qd(7);
qd8 = qd(8);
qd9  = qd(9);
qd10 = qd(10);

% t = 0;
% t = 2*t;
tf = 5;
Bq(2) = q1*exp(-q2^2*(X - t/tf)^2)+q3+q4*X+q5*X^2; %gaussian dependent (q,t)
Bq(3) = q6*exp(-q7^2*(X - t/tf)^2)+q8+q9*X+q10*X^2; %gaussian dependent (q,t)

dBqdq(2,1) = exp(-q2^2*(X - t/tf)^2);
dBqdq(2,2) = -2*q1*q2*exp(-q2^2*(X - t/tf)^2)*(X - t/tf)^2;
dBqdq(2,3) = 1;
dBqdq(2,4) = X;
dBqdq(2,5) = X^2;
dBqdq(3,6) = exp(-q7^2*(X - t/tf)^2);
dBqdq(3,7) = -2*q6*q7*exp(-q7^2*(X - t/tf)^2)*(X - t/tf)^2;
dBqdq(3,8) = 1;
dBqdq(3,9) = X;
dBqdq(3,10) = X^2;

dBqdt(2)   = 2*q1*q2^2*exp(-q2^2*(X - t/tf)^2)*(X/tf - t/tf^2);
dBqdt(3)   = 2*q6*q7^2*exp(-q7^2*(X - t/tf)^2)*(X/tf - t/tf^2);

d2Bqdqdq_qd(2,1) = -2*q2*(X - t/tf)^2*exp(-q2^2*(X - t/tf)^2)*qd2;
d2Bqdqdq_qd(2,2) = -2*q2*(X - t/tf)^2*exp(-q2^2*(X - t/tf)^2)*qd1+(4*q1*q2^2*(X - t/tf)^4*exp(-q2^2*(X - t/tf)^2) - 2*q1*(X - t/tf)^2*exp(-q2^2*(X - t/tf)^2))*qd2;
d2Bqdqdq_qd(2,3) = 0;
d2Bqdqdq_qd(2,4) = 0;
d2Bqdqdq_qd(2,5) = 0;
d2Bqdqdq_qd(3,6) = -2*q7*(X - t/tf)^2*exp(-q7^2*(X - t/tf)^2)*qd7;
d2Bqdqdq_qd(3,7) = -2*q7*(X - t/tf)^2*exp(-q7^2*(X - t/tf)^2)*qd6+(4*q6*q7^2*(X - t/tf)^4*exp(-q7^2*(X - t/tf)^2) - 2*q6*(X - t/tf)^2*exp(-q7^2*(X - t/tf)^2))*qd7;
d2Bqdqdq_qd(3,8) = 0;
d2Bqdqdq_qd(3,9) = 0;
d2Bqdqdq_qd(3,10) = 0;


d2Bqdqdt(2,1) = 2*q2^2*(X/tf - t/tf^2)*exp(-q2^2*(X - t/tf)^2);
d2Bqdqdt(2,2) = 4*q1*q2*(X/tf - t/tf^2)*exp(-q2^2*(X - t/tf)^2) - 4*q1*q2^3*(X - t/tf)^2*(X/tf - t/tf^2)*exp(-q2^2*(X - t/tf)^2);
d2Bqdqdt(2,3) = 0;
d2Bqdqdt(2,4) = 0;
d2Bqdqdt(2,5) = 0;
d2Bqdqdt(3,6) = 2*q7^2*(X/tf - t/tf^2)*exp(-q7^2*(X - t/tf)^2);
d2Bqdqdt(3,7) = 4*q6*q7*(X/tf - t/tf^2)*exp(-q7^2*(X - t/tf)^2) - 4*q6*q7^3*(X - t/tf)^2*(X/tf - t/tf^2)*exp(-q7^2*(X - t/tf)^2);
d2Bqdqdt(3,8) = 0;
d2Bqdqdt(3,9) = 0;
d2Bqdqdt(3,10) = 0;


d2Bqd2t(2)   = 4*q1*q2^4*(X/tf - t/tf^2)^2*exp(-q2^2*(X - t/tf)^2) - (2*q1*q2^2*exp(-q2^2*(X - t/tf)^2))/tf^2;
d2Bqd2t(3)   = 4*q6*q7^4*(X/tf - t/tf^2)^2*exp(-q7^2*(X - t/tf)^2) - (2*q6*q7^2*exp(-q7^2*(X - t/tf)^2))/tf^2;

%% simple kinematic constrain with linear basis
% Bq(2) = q1+q2*X-t; %gaussian dependent (q,t)
% 
% dBqdq(2,1) = 1;
% dBqdq(2,2) = X;
% 
% dBqdt(2)   = -1;
% 
% d2Bqdqdq_qd(2,1) = 0;
% d2Bqdqdq_qd(2,2) = 0;
% 
% d2Bqdqdt(2,1) = 0;
% d2Bqdqdt(2,2) = 0;
% 
% d2Bqd2t(2)   = 0;

%% simple kinematic constrain with non linear basis
% Bq(2) = q1+q1*q2*X-(-1+2*X)*t^2/5; %gaussian dependent (q,t)
% 
% dBqdq(2,1) = 1+q2*X;
% dBqdq(2,2) = q1*X;
% 
% dBqdt(2)   = -(-1+2*X)*2*t/5;
% 
% d2Bqdqdq_qd(2,1) = X*qd2;
% d2Bqdqdq_qd(2,2) = X*qd1;
% 
% d2Bqdqdt(2,1) = 0;
% d2Bqdqdt(2,2) = 0;
% 
% d2Bqd2t(2)   = -(-1+2*X)*2/5;

% %% simple kinematic constrain with non linear basis
% Bq(2) = q1*(1+t^2/5)+q1*q2*X; %gaussian dependent (q,t)
% 
% dBqdq(2,1) = 1+t^2/5+q2*X;
% dBqdq(2,2) = q1*X;
% 
% dBqdt(2)   = q1*2*t/5;
% 
% d2Bqdqdq_qd(2,1) = X*qd2;
% d2Bqdqdq_qd(2,2) = X*qd1;
% 
% d2Bqdqdt(2,1) = 2*t/5;
% d2Bqdqdt(2,2) = 0;
% 
% d2Bqd2t(2)   = q1*2/5;

end