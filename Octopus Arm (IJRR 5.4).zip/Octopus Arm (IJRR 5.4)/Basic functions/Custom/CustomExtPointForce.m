%Function to calculate the custom external point force. Make sure to edit
%CustomExtForce.m file too
%Last modified by Anup Teejo Mathew 30/06/2021

function FextP=CustomExtPointForce(Tr,q,g,J,t,qd,eta,Jdot)

%%%%NOTE%%%%
%Tr: Linkage element,
%q and qd: joint coordinates and their time derivatives,
%g, J, Jd, and eta: transformation matrix, Jacobian, time derivative of jacobian, and screw velocity at every significant point of the linkage
%t: time
%Currently applicable only for independent bases

%Fext should be 6*n column vector where n is the total number of integration points of all soft links (nip) + number of rigid links.
%(Example: linkage with 2 soft links and 1 rigid link (n=nip1+nip2+1)
%Fext should be arranged according to the order of precedence
%Fext should be point force

% Significant points: 1 for every joint, 1 at the center of the rigid link, for soft links at every integration points

% J   = S.Jacobian(q);         %geometric jacobian of the linkage calculated at every significant points
% g   = S.FwdKinematics(q);    %transformation matrix of the linkage calculated at every significant points
% eta = S.ScrewVelocity(q,qd); %Screwvelocity of the linkage calculated at every significant points
% J   = S.Jacobiandot(q,qd);   %time derivative of geometric jacobian of the linkage calculated at every significant points

%%%END%%%

n    = Tr.nsig-Tr.N; %everything except rigid joints
FextP = zeros(6*n,1);

%% Contact

% rr = Tr.VLinks(Tr.LinkIndex(2)).r(0);
% 
% k=200;
% d=20;
% 
% %rod position
% Rp  = Tr.g_ini(end-3:end-1,4);
% 
% i_sig_nj = 1;
% i_sig = 1;
% 
% i=1;
% i_sig    = i_sig+1;%joint
% 
% for j=1:Tr.VLinks(Tr.LinkIndex(i)).npie-1
% 
%     nip = Tr.CVTwists{i}(j+1).nip;
%     Xs  = Tr.CVTwists{i}(j+1).Xs;
%     r   = Tr.VLinks(Tr.LinkIndex(i)).r{j};
% 
%     for ii=1:nip
%         g_here = g((i_sig-1)*4+1:i_sig*4,:);
%         r21    = Rp-g_here(1:3,4);
%         r21(1) = 0; %x coordinate is irrelevant here
%         r21_n  = norm(r21);
%         r_here = r(Xs(ii));
%         d21    = r21_n-rr-r_here;
% 
%         if d21<0 %if contact
%             r21_u = -r21/r21_n;%vector in direction from rod to center of cross section
%             eta_here = eta((i_sig-1)*6+1:i_sig*6);
%             eta_here(1:3)=[0 0 0]';
%             eta_d  = zeros(6,1)-dinamico_Adjoint(g_here)*eta_here; % in global frame
%             d21dot = eta_d(4:6)'*r21_u; %normal component
% 
%             g_here(1:3,4) = zeros(3,1);
%             Ad_g_here_inv = dinamico_Adjoint(ginv(g_here));
% 
%             FextP((i_sig_nj-1)*6+1:i_sig_nj*6) = FextP((i_sig_nj-1)*6+1:i_sig_nj*6)+Ad_g_here_inv*[[0 0 0]'; (k*-d21+d*d21dot)*r21_u];
%         end
%         i_sig    = i_sig+1;
%         i_sig_nj = i_sig_nj+1;
%     end
% 
% end


end