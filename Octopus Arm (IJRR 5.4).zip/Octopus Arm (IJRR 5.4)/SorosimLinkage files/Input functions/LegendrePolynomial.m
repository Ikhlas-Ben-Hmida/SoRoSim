function LP = LegendrePolynomial(n)

syms X
LP = ((2*X-1)^2-1)^n;
for i=1:n
    LP = diff(LP,X);
end
LP = LP/4^n/factorial(n);

if n==0
    LP = @(X) 1;
else
    LP = matlabFunction(LP);
end

end