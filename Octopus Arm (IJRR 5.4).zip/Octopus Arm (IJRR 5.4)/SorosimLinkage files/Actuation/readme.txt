This folder contains functions that are used to gather userinput for
lumped (joint) actuation and distributed (cable) actuation.
the apps are used to set the cable parameters and cableDisplay is used to 
plot the cable and show it's path inside the soft link