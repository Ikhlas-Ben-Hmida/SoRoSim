function [Bq,dBqdq,d2Bqdqdq_qd] = B_CustomQDependent(X,varargin)

% OCTOPUS SIMULATION BASIC ONE

%Add more and change file name in twist if needed
%Bq should be linearly independent with others
Bq    = zeros(6,1); % for linear basis Bq = B(X,q)

dof = 3; % define dof here
dBqdq = zeros(6,dof);
d2Bqdqdq_qd = zeros(6,dof);
if nargin==1
    q  = zeros(dof,1);
    qd = zeros(dof,1);
elseif nargin==2
    q  = varargin{1};
    qd = zeros(dof,1);
elseif nargin==3
    q  = varargin{1};
    qd = varargin{2};
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% CUSTOM B(q), Tentacle base Function, in 1 dof (My)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


q1 = q(1);
q2 = q(2);
q3 = q(3);
qd1 = qd(1);
qd2 = qd(2);
qd3 = qd(3);

Bq(2) = q1/(1+(q2*(X-q3))^2);

dBqdq(2,1) = 1/(q2^2*(X - q3)^2 + 1);
dBqdq(2,2) = -(2*q1*q2*(X - q3)^2)/(q2^2*(X - q3)^2 + 1)^2;
dBqdq(2,3) = (q1*q2^2*(2*X - 2*q3))/(q2^2*(X - q3)^2 + 1)^2;

d2Bqdqdq_qd(2,1) = qd1/(q2^2*(X - q3)^2 + 1) - (2*q1*q2*qd2*(X - q3)^2)/(q2^2*(X - q3)^2 + 1)^2 + (q1*q2^2*qd3*(2*X - 2*q3))/(q2^2*(X - q3)^2 + 1)^2;
d2Bqdqdq_qd(2,2) = (2*q1*q2*qd3*(2*X - 2*q3))/(q2^2*(X - q3)^2 + 1)^2 - (2*q2*qd1*(X - q3)^2)/(q2^2*(X - q3)^2 + 1)^2 - (2*q1*qd2*(X - q3)^2)/(q2^2*(X - q3)^2 + 1)^2 + (8*q1*q2^2*qd2*(X - q3)^4)/(q2^2*(X - q3)^2 + 1)^3 - (4*q1*q2^3*qd3*(X - q3)^2*(2*X - 2*q3))/(q2^2*(X - q3)^2 + 1)^3;
d2Bqdqdq_qd(2,3) = (q2^2*qd1*(2*X - 2*q3))/(q2^2*(X - q3)^2 + 1)^2 - (2*q1*q2^2*qd3)/(q2^2*(X - q3)^2 + 1)^2 + (2*q1*q2^4*qd3*(2*X - 2*q3)^2)/(q2^2*(X - q3)^2 + 1)^3 + (2*q1*q2*qd2*(2*X - 2*q3))/(q2^2*(X - q3)^2 + 1)^2 - (4*q1*q2^3*qd2*(X - q3)^2*(2*X - 2*q3))/(q2^2*(X - q3)^2 + 1)^3;

end