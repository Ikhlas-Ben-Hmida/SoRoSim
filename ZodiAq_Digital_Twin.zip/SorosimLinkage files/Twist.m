%Class that assigns DoFs and Bases to link pieces and can calculate the
%twist given joint angles 
%Last modified by Anup Teejo Mathew 14.06.2022

classdef Twist < handle
    
    properties
        Type         %Base type (Mononomial, Lagrange Polynomial, Linear Interpolation, Gaussian, Custom, Non-linear Gaussian)
        Bdof         %(6x1) array specifying the allowable DoFs of a soft piece. 1 if allowed 0 if not.
        Bodr         %(6x1) array specifying the order of allowed DoF (0: constant, 1: linear, 2: quadratic,...)
        Xs           %Gauss quadrature points
        B            %(6xdof) Base matrix calculated at lumped joints or ((6xnGauss)xdof) base matrices computed at every significant points of a soft division
        B_Z1         %Base calculated at 4th order first Zanna point (Xs+Z1*(delta(Xs)))
        B_Z2         %Base calculated at 4th order second Zanna point (Xs+Z2*(delta(Xs)))
        B_Z          %Base calculated at 2nd order Zanna point 
        Bh           %Function handle for Custom base
        xi_starfn    %Reference strain vector as a function of X
        xi_star      %(6x1) reference strain vector at the lumped joint or ((6xnGauss)x4) reference strain vectors computed at Gauss quadrature and Zannah collocation points
        dof          %degress of freedom of each base
    end
    
    methods
        
        function T = Twist(i,j,Xs,B)
            
            if nargin==3
                
                T.Xs   = Xs;
                nGauss = length(Xs);             %number of Gauss points for Lagrange model
                
                Z1     = 1/2-sqrt(3)/6;          %Zanna quadrature coefficient 4th order
                Z2     = 1/2+sqrt(3)/6;          %Zanna quadrature coefficient 4th order
                Z      = 1/2;                    %Zanna quadrature coefficient 2nd order
               
                basedef(i,j);
                load('Base_properties.mat','Type','Bdof','Bodr','xi_stars')
                
                T.Type = Type;
                T.Bdof = Bdof;
                T.Bodr = Bodr;
                % computing reference strains according to user
                % input in xi_stars

                syms X;
                xi_stars1 = str2sym(xi_stars{1});
                xi_stars2 = str2sym(xi_stars{2});
                xi_stars3 = str2sym(xi_stars{3});
                xi_stars4 = str2sym(xi_stars{4});
                xi_stars5 = str2sym(xi_stars{5});
                xi_stars6 = str2sym(xi_stars{6});
                xi_stars  = [xi_stars1;xi_stars2;xi_stars3;xi_stars4;xi_stars5;xi_stars6];

                if any(has(xi_stars,X))
                    xi_starfn = matlabFunction(xi_stars);
                else 
                    xi_starfn = str2func(['@(X) [' num2str(double(xi_stars')) ']''']);
                end

                T.xi_starfn = xi_starfn;

                xi_star        = zeros(6*nGauss,4); % precomputation at all gauss and zannah gauss points
                xi_star(1:6,1) = xi_starfn(Xs(1)); %1
                for ii=2:nGauss
                    xi_star((ii-1)*6+1:ii*6,1)     = xi_starfn(Xs(ii)); %2 to nGauss
                    xi_star((ii-2)*6+1:(ii-1)*6,2) = xi_starfn(Xs(ii-1)+Z1*(Xs(ii)-Xs(ii-1))); %1 to nGauss-1
                    xi_star((ii-2)*6+1:(ii-1)*6,3) = xi_starfn(Xs(ii-1)+Z2*(Xs(ii)-Xs(ii-1))); %1 to nGauss-1
                    xi_star((ii-2)*6+1:(ii-1)*6,4) = xi_starfn(Xs(ii-1)+Z*(Xs(ii)-Xs(ii-1))); %1 to nGauss-1
                end

                T.xi_star = xi_star;
                    
                switch Type
                    case 'Mononomial'
                        dof  = sum(Bdof.*(Bodr+1));
                        B    = zeros(nGauss*6,dof);
                        B_Z1 = zeros(nGauss*6,dof);
                        B_Z2 = zeros(nGauss*6,dof);
                        B_Z  = zeros(nGauss*6,dof);

                        ii = 1;
                        X = Xs(ii);
                        B(1:6,:) = B_Mononomial(X,Bdof,Bodr);
                        for ii=2:nGauss
                            X = Xs(ii);
                            B(6*(ii-1)+1:6*ii,:) = B_Mononomial(X,Bdof,Bodr);
                            X = Xs(ii-1)+Z1*(Xs(ii)-Xs(ii-1));
                            B_Z1(6*(ii-2)+1:6*(ii-1),:) = B_Mononomial(X,Bdof,Bodr);
                            X = Xs(ii-1)+Z2*(Xs(ii)-Xs(ii-1));
                            B_Z2(6*(ii-2)+1:6*(ii-1),:) = B_Mononomial(X,Bdof,Bodr);
                            X = Xs(ii-1)+Z*(Xs(ii)-Xs(ii-1));
                            B_Z(6*(ii-2)+1:6*(ii-1),:)  = B_Mononomial(X,Bdof,Bodr);                                
                        end
                        file = 'B_Mononomial';
                        Bh   = str2func(['@(X,Bdof,Bodr)',file,'(X,Bdof,Bodr)']);
                    case 'Legendre Polynomial'
                        dof      = sum(Bdof.*(Bodr+1));
                        B        = zeros(nGauss*6,dof);
                        B_Z1     = zeros(nGauss*6,dof);
                        B_Z2     = zeros(nGauss*6,dof);
                        B_Z      = zeros(nGauss*6,dof);

                        ii = 1;
                        X = Xs(ii);
                        B(1:6,:) = B_LegendrePolynomial(X,Bdof,Bodr);
                        for ii=2:nGauss
                            X = Xs(ii);
                            B(6*(ii-1)+1:6*ii,:) = B_LegendrePolynomial(X,Bdof,Bodr);
                            X = Xs(ii-1)+Z1*(Xs(ii)-Xs(ii-1));
                            B_Z1(6*(ii-2)+1:6*(ii-1),:) = B_LegendrePolynomial(X,Bdof,Bodr);
                            X = Xs(ii-1)+Z2*(Xs(ii)-Xs(ii-1));
                            B_Z2(6*(ii-2)+1:6*(ii-1),:) = B_LegendrePolynomial(X,Bdof,Bodr);
                            X = Xs(ii-1)+Z*(Xs(ii)-Xs(ii-1));
                            B_Z(6*(ii-2)+1:6*(ii-1),:)  = B_LegendrePolynomial(X,Bdof,Bodr);                                
                        end
                        file = 'B_LegendrePolynomial';
                        Bh   = str2func(['@(X,Bdof,Bodr)',file,'(X,Bdof,Bodr)']);
                    case 'Chebychev'
                        dof      = sum(Bdof.*(Bodr+1));
                        B        = zeros(nGauss*6,dof);
                        B_Z1     = zeros(nGauss*6,dof);
                        B_Z2     = zeros(nGauss*6,dof);
                        B_Z      = zeros(nGauss*6,dof);

                        ii = 1;
                        X = Xs(ii);
                        B(1:6,:) = B_Chebychev(X,Bdof,Bodr);
                        for ii=2:nGauss
                            X = Xs(ii);
                            B(6*(ii-1)+1:6*ii,:) = B_LegendrePolynomial(X,Bdof,Bodr);
                            X = Xs(ii-1)+Z1*(Xs(ii)-Xs(ii-1));
                            B_Z1(6*(ii-2)+1:6*(ii-1),:) = B_LegendrePolynomial(X,Bdof,Bodr);
                            X = Xs(ii-1)+Z2*(Xs(ii)-Xs(ii-1));
                            B_Z2(6*(ii-2)+1:6*(ii-1),:) = B_LegendrePolynomial(X,Bdof,Bodr);
                            X = Xs(ii-1)+Z*(Xs(ii)-Xs(ii-1));
                            B_Z(6*(ii-2)+1:6*(ii-1),:)  = B_LegendrePolynomial(X,Bdof,Bodr);                                
                        end
                        file = 'B_Chebychev';
                        Bh   = str2func(['@(X,Bdof,Bodr)',file,'(X,Bdof,Bodr)']);
                    case 'Fourier'
                        dof  = sum(Bdof.*(2*Bodr+1));
                        B    = zeros(nGauss*6,dof);
                        B_Z1 = zeros(nGauss*6,dof);
                        B_Z2 = zeros(nGauss*6,dof);
                        B_Z  = zeros(nGauss*6,dof);

                        ii = 1;
                        X = Xs(ii);
                        B(1:6,:) = B_Fourier(X,Bdof,Bodr);
                        for ii=2:nGauss
                            X = Xs(ii);
                            B(6*(ii-1)+1:6*ii,:) = B_Fourier(X,Bdof,Bodr);
                            X = Xs(ii-1)+Z1*(Xs(ii)-Xs(ii-1));
                            B_Z1(6*(ii-2)+1:6*(ii-1),:) = B_Fourier(X,Bdof,Bodr);
                            X = Xs(ii-1)+Z2*(Xs(ii)-Xs(ii-1));
                            B_Z2(6*(ii-2)+1:6*(ii-1),:) = B_Fourier(X,Bdof,Bodr);
                            X = Xs(ii-1)+Z*(Xs(ii)-Xs(ii-1));
                            B_Z(6*(ii-2)+1:6*(ii-1),:)  = B_Fourier(X,Bdof,Bodr);                                
                        end
                        file = 'B_Fourier';
                        Bh   = str2func(['@(X,Bdof,Bodr)',file,'(X,Bdof,Bodr)']);
                    case 'Linear Interpolation'
                        dof      = sum(Bdof.*(Bodr+1));
                        B        = zeros(nGauss*6,dof);
                        B_Z1     = zeros(nGauss*6,dof);
                        B_Z2     = zeros(nGauss*6,dof);
                        B_Z      = zeros(nGauss*6,dof);

                        ii = 1;
                        X = Xs(ii);
                        B(1:6,:) = B_LinearInterpolation(X,Bdof,Bodr);
                        for ii=2:nGauss
                            X = Xs(ii);
                            B(6*(ii-1)+1:6*ii,:) = B_LinearInterpolation(X,Bdof,Bodr);
                            X = Xs(ii-1)+Z1*(Xs(ii)-Xs(ii-1));
                            B_Z1(6*(ii-2)+1:6*(ii-1),:) = B_LinearInterpolation(X,Bdof,Bodr);
                            X = Xs(ii-1)+Z2*(Xs(ii)-Xs(ii-1));
                            B_Z2(6*(ii-2)+1:6*(ii-1),:) = B_LinearInterpolation(X,Bdof,Bodr);
                            X = Xs(ii-1)+Z*(Xs(ii)-Xs(ii-1));
                            B_Z(6*(ii-2)+1:6*(ii-1),:)  = B_LinearInterpolation(X,Bdof,Bodr);                                
                        end
                        file = 'B_LinearInterpolation';
                        Bh   = str2func(['@(X,Bdof,Bodr)',file,'(X,Bdof,Bodr)']);
                    case 'Gaussian'
                        dof      = sum(Bdof.*(Bodr+1));
                        B        = zeros(nGauss*6,dof);
                        B_Z1     = zeros(nGauss*6,dof);
                        B_Z2     = zeros(nGauss*6,dof);
                        B_Z      = zeros(nGauss*6,dof);

                        ii = 1;
                        X = Xs(ii);
                        B(1:6,:) = B_Gaussian(X,Bdof,Bodr);
                        for ii=2:nGauss
                            X = Xs(ii);
                            B(6*(ii-1)+1:6*ii,:) = B_Gaussian(X,Bdof,Bodr);
                            X = Xs(ii-1)+Z1*(Xs(ii)-Xs(ii-1));
                            B_Z1(6*(ii-2)+1:6*(ii-1),:) = B_Gaussian(X,Bdof,Bodr);
                            X = Xs(ii-1)+Z2*(Xs(ii)-Xs(ii-1));
                            B_Z2(6*(ii-2)+1:6*(ii-1),:) = B_Gaussian(X,Bdof,Bodr);
                            X = Xs(ii-1)+Z*(Xs(ii)-Xs(ii-1));
                            B_Z(6*(ii-2)+1:6*(ii-1),:)  = B_Gaussian(X,Bdof,Bodr);                                
                        end
                        file = 'B_Gaussian';
                        Bh   = str2func(['@(X,Bdof,Bodr)',file,'(X,Bdof,Bodr)']);
                    case 'Inverse Multi-quadratic'
                        dof  = sum(Bdof.*(Bodr+1));
                        B    = zeros(nGauss*6,dof);
                        B_Z1 = zeros(nGauss*6,dof);
                        B_Z2 = zeros(nGauss*6,dof);
                        B_Z  = zeros(nGauss*6,dof);

                        ii = 1;
                        X = Xs(ii);
                        B(1:6,:) = B_IMQ(X,Bdof,Bodr);
                        for ii=2:nGauss
                            X = Xs(ii);
                            B(6*(ii-1)+1:6*ii,:) = B_IMQ(X,Bdof,Bodr);
                            X = Xs(ii-1)+Z1*(Xs(ii)-Xs(ii-1));
                            B_Z1(6*(ii-2)+1:6*(ii-1),:) = B_IMQ(X,Bdof,Bodr);
                            X = Xs(ii-1)+Z2*(Xs(ii)-Xs(ii-1));
                            B_Z2(6*(ii-2)+1:6*(ii-1),:) = B_IMQ(X,Bdof,Bodr);
                            X = Xs(ii-1)+Z*(Xs(ii)-Xs(ii-1));
                            B_Z(6*(ii-2)+1:6*(ii-1),:)  = B_IMQ(X,Bdof,Bodr);                                
                        end
                        file = 'B_IMQ';
                        Bh   = str2func(['@(X,Bdof,Bodr)',file,'(X,Bdof,Bodr)']);
                    case 'Custom Independent'
                        %select function, find dof
                        file = 'B_CustomIndependent';
                        Bh   = str2func(file);
                        B    = Bh(0);
                        dof  = size(B,2);
                        B    = zeros(nGauss*6,dof);
                        B_Z1 = zeros(nGauss*6,dof);
                        B_Z2 = zeros(nGauss*6,dof);
                        B_Z  = zeros(nGauss*6,dof);
                        
                        ii = 1;
                        X = Xs(ii);
                        B(1:6,:) = Bh(X);
                        for ii=2:nGauss
                            X = Xs(ii);
                            B(6*(ii-1)+1:6*ii,:) = Bh(X);
                            X = Xs(ii-1)+Z1*(Xs(ii)-Xs(ii-1));
                            B_Z1(6*(ii-2)+1:6*(ii-1),:) = Bh(X);
                            X = Xs(ii-1)+Z2*(Xs(ii)-Xs(ii-1));
                            B_Z2(6*(ii-2)+1:6*(ii-1),:) = Bh(X);
                            X = Xs(ii-1)+Z*(Xs(ii)-Xs(ii-1));
                            B_Z(6*(ii-2)+1:6*(ii-1),:)  = Bh(X);                                
                        end
                     case 'Custom Dependent'
                        %select function, find dof
                        file = 'B_CustomDependent';
                        Bh   = str2func(file);
                        [~,dBqdq] = Bh(0);
                        dof  = size(dBqdq,2);
                        B    = zeros(nGauss*6,dof);
                        B_Z1 = zeros(nGauss*6,dof);
                        B_Z2 = zeros(nGauss*6,dof);
                        B_Z  = zeros(nGauss*6,dof);
                end
                
                T.B    = B;
                T.B_Z1 = B_Z1;
                T.B_Z2 = B_Z2;
                T.B_Z  = B_Z;
                T.Bh   = Bh;
                T.dof  = dof;
                
            elseif nargin==4
                
                T.B       = B;

            elseif nargin==0
                
                xi_starfn   = str2func('@(X) [0 0 0 1 0 0]''');
                T.B         = [];
                T.xi_starfn = xi_starfn;
                T.Bodr      = zeros(6,1);
                T.Bdof      = zeros(6,1);
                T.dof       = 0;
                
            end
            
        end
    end
        
    methods
        %% Set and property update functions
        function set.Bdof(T, value)
            T.Bdof = value;
            T.Update();
        end
        function set.Bodr(T, value)
            T.Bodr = value;
            T.Update();
        end
        function set.Type(T, value)
            T.Type = value;
            T.UpdateBh();
        end
        function set.Xs(T, value)
            T.Xs = value;
            T.Update();
            T.Updatexi_star();
        end
        function UpdateBh(T)
            switch T.Type
                case 'Mononomial'
                    file = 'B_Mononomial';
                    T.Bh   = str2func(['@(X,Bdof,Bodr)',file,'(X,Bdof,Bodr)']);
                case 'Legendre Polynomial'
                    file = 'B_LegendrePolynomial';
                    T.Bh   = str2func(['@(X,Bdof,Bodr)',file,'(X,Bdof,Bodr)']);
                case 'Chebychev'
                    file = 'B_Chebychev';
                    T.Bh   = str2func(['@(X,Bdof,Bodr)',file,'(X,Bdof,Bodr)']);
                case 'Fourier'
                    file = 'B_Fourier';
                    T.Bh   = str2func(['@(X,Bdof,Bodr)',file,'(X,Bdof,Bodr)']);
                case 'Linear Interpolation'
                    file = 'B_LinearInterpolation';
                    T.Bh   = str2func(['@(X,Bdof,Bodr)',file,'(X,Bdof,Bodr)']);
                case 'Gaussian'
                    file = 'B_Gaussian';
                    T.Bh   = str2func(['@(X,Bdof,Bodr)',file,'(X,Bdof,Bodr)']);
                case 'Inverse Multi-quadratic'
                    file = 'B_IMQ';
                    T.Bh   = str2func(['@(X,Bdof,Bodr)',file,'(X,Bdof,Bodr)']);
                case 'Custom Independent'
                    file = 'B_CustomIndependent';
                    T.Bh   = str2func(file);
                case 'Custom Dependent'
                    file = 'B_CustomDependent';
                    T.Bh   = str2func(file);                        
            end
        end
        function set.Bh(T, value)
            T.Bh = value;
            T.Update();
        end
        
        function Update(T)%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%CHANGE%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            if isempty(T.dof)
                return
            end
            
            nGauss = length(T.Xs);             %number of Gauss points for Lagrange model
                
            Z1     = 1/2-sqrt(3)/6;          %Zanna quadrature coefficient 4th order
            Z2     = 1/2+sqrt(3)/6;          %Zanna quadrature coefficient 4th order
            Z      = 1/2;                    %Zanna quadrature coefficient 2nd order 
            
            switch T.Type
                case {'Mononomial','Legendre Polynomial','Chebychev','Fourier','Linear Interpolation','Gaussian','Inverse Multi-quadratic'}
                    if strcmp(T.Type,'Fourier')
                        T.dof  = sum(T.Bdof.*(2*T.Bodr+1));
                    else
                        T.dof  = sum(T.Bdof.*(T.Bodr+1));
                    end
                    T.B    = zeros(nGauss*6,T.dof);
                    T.B_Z1 = zeros(nGauss*6,T.dof);
                    T.B_Z2 = zeros(nGauss*6,T.dof);
                    T.B_Z  = zeros(nGauss*6,T.dof);

                    ii = 1;
                    X = T.Xs(ii);
                    T.B(1:6,:) = T.Bh(X,T.Bdof,T.Bodr);
                    for ii=2:nGauss
                        X = T.Xs(ii);
                        T.B(6*(ii-1)+1:6*ii,:) = T.Bh(X,T.Bdof,T.Bodr);
                        X = T.Xs(ii-1)+Z1*(T.Xs(ii)-T.Xs(ii-1));
                        T.B_Z1(6*(ii-2)+1:6*(ii-1),:) = T.Bh(X,T.Bdof,T.Bodr);
                        X = T.Xs(ii-1)+Z2*(T.Xs(ii)-T.Xs(ii-1));
                        T.B_Z2(6*(ii-2)+1:6*(ii-1),:) = T.Bh(X,T.Bdof,T.Bodr);
                        X = T.Xs(ii-1)+Z*(T.Xs(ii)-T.Xs(ii-1));
                        T.B_Z(6*(ii-2)+1:6*(ii-1),:)  = T.Bh(X,T.Bdof,T.Bodr);                                
                    end
                case 'Custom Independent'
                    B0     = T.Bh(0);
                    T.dof  = size(B0,2);
                    T.B    = zeros(nGauss*6,T.dof);
                    T.B_Z1 = zeros(nGauss*6,T.dof);
                    T.B_Z2 = zeros(nGauss*6,T.dof);
                    T.B_Z  = zeros(nGauss*6,T.dof);

                    ii = 1;
                    X = T.Xs(ii);
                    T.B(1:6,:) = T.Bh(X);
                    for ii=2:nGauss
                        X = T.Xs(ii);
                        T.B(6*(ii-1)+1:6*ii,:) = T.Bh(X);
                        X = T.Xs(ii-1)+Z1*(T.Xs(ii)-T.Xs(ii-1));
                        T.B_Z1(6*(ii-2)+1:6*(ii-1),:) = T.Bh(X);
                        X = T.Xs(ii-1)+Z2*(T.Xs(ii)-T.Xs(ii-1));
                        T.B_Z2(6*(ii-2)+1:6*(ii-1),:) = T.Bh(X);
                        X = T.Xs(ii-1)+Z*(T.Xs(ii)-T.Xs(ii-1));
                        T.B_Z(6*(ii-2)+1:6*(ii-1),:)  = T.Bh(X);                                
                    end
                 case 'Custom Dependent'
                    [~,dBqdq] = T.Bh(0);
                    T.dof     = size(dBqdq,2);
                    T.B    = zeros(nGauss*6,T.dof);
                    T.B_Z1 = zeros(nGauss*6,T.dof);
                    T.B_Z2 = zeros(nGauss*6,T.dof);
                    T.B_Z  = zeros(nGauss*6,T.dof);
            end

        end
        
        function set.xi_starfn(T, value)
            T.xi_starfn = value;
            T.Updatexi_star();
        end
        function Updatexi_star(T)
            
            if isempty(T.dof)
                return
            end
            nGauss = length(T.Xs);
            Z1     = 1/2-sqrt(3)/6;          %Zanna quadrature coefficient
            Z2     = 1/2+sqrt(3)/6;          %Zanna quadrature coefficient
            Z      = 1/2;                    %Zanna quadrature coefficient 2nd order
            
            T.xi_star        = zeros(6*nGauss,4);
            T.xi_star(1:6,1) = T.xi_starfn(T.Xs(1)); %1
            for ii=2:nGauss
                T.xi_star((ii-1)*6+1:ii*6,1)     = T.xi_starfn(T.Xs(ii)); %2 to nGauss
                T.xi_star((ii-2)*6+1:(ii-1)*6,2) = T.xi_starfn(T.Xs(ii-1)+Z1*(T.Xs(ii)-T.Xs(ii-1))); %1 to nGauss-1
                T.xi_star((ii-2)*6+1:(ii-1)*6,3) = T.xi_starfn(T.Xs(ii-1)+Z2*(T.Xs(ii)-T.Xs(ii-1))); %1 to nGauss-1
                T.xi_star((ii-2)*6+1:(ii-1)*6,4) = T.xi_starfn(T.Xs(ii-1)+Z*(T.Xs(ii)-T.Xs(ii-1))); %1 to nGauss-1
            end
        end
    end
    
end

