%Function that calculates the screw velocity (eta) at every significant point
%(24.05.2021)

function eta = ScrewVelocity(Tr,q,qd)

if isrow(q)
    q=q';
end
if isrow(qd)
    qd=qd';
end

N         = Tr.N;
nsig      = Tr.nsig;
ndof      = Tr.ndof;
g_ini     = Tr.g_ini;
g_Ltip    = repmat(eye(4),N,1);
J_Ltip    = repmat(zeros(6,ndof),N,1);
iLpre     = Tr.iLpre;
eta       = zeros(6*nsig,1);
dof_start = 1; %starting dof of current piece
i_sig     = 1;

for i = 1:N
    
    if iLpre(i)>0
        g_here       = g_Ltip((iLpre(i)-1)*4+1:iLpre(i)*4,:)*g_ini((i-1)*4+1:i*4,:);
        Ad_g_ini_inv = dinamico_Adjoint(ginv(g_ini((i-1)*4+1:i*4,:)));
        J_here       = Ad_g_ini_inv*J_Ltip((iLpre(i)-1)*6+1:iLpre(i)*6,:);
    else
        g_here   = g_ini((i-1)*4+1:i*4,:);
        J_here   = zeros(6,ndof);
    end    
    
    %Joint
    dof_here = Tr.CVTwists{i}(1).dof;
    q_here   = q(dof_start:dof_start+dof_here-1);
    qd_here  = qd(dof_start:dof_start+dof_here-1);
    B_here   = Tr.CVTwists{i}(1).B;
    xi_star  = Tr.CVTwists{i}(1).xi_star;
    
    if dof_here == 0 %fixed joint (N)
        g_joint   = eye(4);
        TgB_here  = zeros(6,ndof);
    else
        if Tr.VLinks(Tr.LinkIndex(i)).jointtype == 'U' %special case for universal joint. Considered as 2 revolute joints
            % first revolute joint
            xi           = B_here(:,1)*q_here(1)+xi_star;
            [g_joint,Tg] = variable_expmap_gTg(xi);
            
            TgB_here               = zeros(6,ndof);
            TgB_here(:,dof_start)  = Tg*B_here(:,1);
            
            g_here         = g_here*g_joint;
            Ad_g_joint_inv = dinamico_Adjoint(ginv(g_joint));
            J_here         = Ad_g_joint_inv*(J_here+TgB_here);
            
            % second revolute joint
            xi           = B_here(:,2)*q_here(2)+xi_star;
            [g_joint,Tg] = variable_expmap_gTg(xi);
            
            TgB_here                 = zeros(6,ndof);
            TgB_here(:,dof_start+1)  = Tg*B_here(:,2);

        else
            xi           = B_here*q_here+xi_star;
            [g_joint,Tg] = variable_expmap_gTg(xi);

            TgB_here                                    = zeros(6,ndof);
            TgB_here(:,dof_start:dof_start+dof_here-1)  = Tg*B_here;
        end
    end
    
    %updating g, Jacobian, Jacobian_dot and eta
    g_here         = g_here*g_joint;
    Ad_g_joint_inv = dinamico_Adjoint(ginv(g_joint));
    J_here         = Ad_g_joint_inv*(J_here+TgB_here);

    eta_here                   = J_here*qd;
    eta((i_sig-1)*6+1:i_sig*6) = eta_here;
    i_sig = i_sig+1;
    
    if Tr.VLinks(Tr.LinkIndex(i)).linktype == 'r'
        gi        = Tr.VLinks(Tr.LinkIndex(i)).gi;
        g_here    = g_here*gi;
        Ad_gi_inv = dinamico_Adjoint(ginv(gi));
        J_here    = Ad_gi_inv*J_here;
        eta_here  = J_here*qd;
        
        eta((i_sig-1)*6+1:i_sig*6,:) = eta_here;
        i_sig                        = i_sig+1;
        
        % bringing all quantities to the end of rigid link
        gf        = Tr.VLinks(Tr.LinkIndex(i)).gf;
        g_here    = g_here*gf;
        Ad_gf_inv = dinamico_Adjoint(ginv(gf));
        J_here    = Ad_gf_inv*J_here;
    end
    
    dof_start = dof_start+dof_here;
    
    for j = 1:Tr.VLinks(Tr.LinkIndex(i)).npie-1 %will run only if soft link
        
        dof_here = Tr.CVTwists{i}(j+1).dof;
        q_here   = q(dof_start:dof_start+dof_here-1);
        qd_here  = qd(dof_start:dof_start+dof_here-1);
        Bdof     = Tr.CVTwists{i}(j+1).Bdof;
        Bodr     = Tr.CVTwists{i}(j+1).Bodr;
        xi_star  = Tr.CVTwists{i}(j+1).xi_star;
        gi       = Tr.VLinks(Tr.LinkIndex(i)).gi{j};
        lpf      = Tr.VLinks(Tr.LinkIndex(i)).lp{j};
        Xs       = Tr.VLinks(Tr.LinkIndex(i)).Xs{j};
        nGauss   = Tr.VLinks(Tr.LinkIndex(i)).nGauss{j};
        
        %Estimate B_scale
        q_scale_here  = Tr.q_scale(dof_start:dof_start+dof_here-1);
        doftheta_here = Bdof(1:3)'*(Bodr(1:3)+[1 1 1]');
        q_scale_here(1:doftheta_here) = q_scale_here(1:doftheta_here)*lpf;
        B_scale = repmat(q_scale_here',6*nGauss,1);
        
        if Tr.Z_order==4
            B_Z1       = Tr.CVTwists{i}(j+1).B_Z1./B_scale; %actual B
            B_Z2       = Tr.CVTwists{i}(j+1).B_Z2./B_scale; %actual B
        else %order 2
            B_Z        = Tr.CVTwists{i}(j+1).B_Z./B_scale; %actual B
        end
        
        %updating g, Jacobian, Jacobian_dot and eta at X=0
        g_here    = g_here*gi;
        Ad_gi_inv = dinamico_Adjoint(ginv(gi));
        J_here    = Ad_gi_inv*J_here;
        eta_here  = J_here*qd;
        
        eta((i_sig-1)*6+1:i_sig*6,:) = eta_here;
        i_sig                        = i_sig+1;
        
        for ii = 2:nGauss
            
            H    = (Xs(ii)-Xs(ii-1))*lpf;
            
            if Tr.Z_order==4
                
                B_Z1here      = B_Z1(6*(ii-2)+1:6*(ii-1),:);%note this step
                B_Z2here      = B_Z2(6*(ii-2)+1:6*(ii-1),:);
                xi_starZ1here = xi_star(6*(ii-2)+1:6*(ii-1),2);
                xi_starZ2here = xi_star(6*(ii-2)+1:6*(ii-1),3);
                xi_Z1here     = B_Z1here*q_here+xi_starZ1here;
                xi_Z2here     = B_Z2here*q_here+xi_starZ2here;
                ad_xi_Z1here  = dinamico_adj(xi_Z1here);
                Gamma_here    = (H/2)*(xi_Z1here+xi_Z2here)+...
                                ((sqrt(3)*H^2)/12)*ad_xi_Z1here*xi_Z2here;
                BGamma_here   = (H/2)*(B_Z1here+B_Z2here)+...
                                ((sqrt(3)*H^2)/12)*(ad_xi_Z1here*B_Z2here-dinamico_adj(xi_Z2here)*B_Z1here); %choice of order from use          
            else % order 2
                B_Zhere      = B_Z(6*(ii-2)+1:6*(ii-1),:);%note this step
                xi_starZhere = xi_star(6*(ii-2)+1:6*(ii-1),4);
                xi_Zhere     = B_Zhere*q_here+xi_starZhere;
                Gamma_here   = H*xi_Zhere;
                BGamma_here  = H*B_Zhere;
            end
            
            [gh,TGamma_here]=variable_expmap_gTg(Gamma_here); % mex code, C program
            
            TBGamma_here                                    = zeros(6,ndof);
            TBGamma_here(:,dof_start:dof_start+dof_here-1)  = TGamma_here*BGamma_here;
            
            %updating g, Jacobian, Jacobian_dot and eta
            g_here     = g_here*gh;
            Ad_gh_inv  = dinamico_Adjoint(ginv(gh));
            J_here     = Ad_gh_inv*(J_here+TBGamma_here);
            eta_here   = J_here*qd;
            
            eta((i_sig-1)*6+1:i_sig*6,:) = eta_here;
            i_sig                        = i_sig+1;
            
        end
        %updating g, Jacobian, Jacobian_dot and eta at X=L
        gf        = Tr.VLinks(Tr.LinkIndex(i)).gf{j};
        g_here    = g_here*gf;
        Ad_gf_inv = dinamico_Adjoint(ginv(gf));
        J_here    = Ad_gf_inv*J_here;
        
        dof_start  = dof_start+dof_here;
    end
    g_Ltip((i-1)*4+1:i*4,:) = g_here;
    J_Ltip((i-1)*6+1:i*6,:) = J_here;
end
end

