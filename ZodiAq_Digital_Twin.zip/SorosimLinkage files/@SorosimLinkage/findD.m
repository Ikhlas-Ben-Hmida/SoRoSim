%Computes the generalized damping matrix for the linkage
%Last modified by Anup Teejo Mathew 02.03.2022
function D = findD(Tr,q)
if nargin==1
    q=zeros(Tr.ndof);
end
CD = cell(Tr.N,1); 

dof_start = 1;
for i=1:Tr.N
    
    CD{i}   = cell(Tr.VLinks(Tr.LinkIndex(i)).npie,1); 
    VTwists = Tr.CVTwists{i};
    %for joint (rigid link)
    if Tr.VLinks(Tr.LinkIndex(i)).jointtype=='N'
        CD{i}{1} = [];
    else
        CD{i}{1} = zeros(VTwists(1).dof);
    end
    dof_start = dof_start+VTwists(1).dof;
    for j=1:(Tr.VLinks(Tr.LinkIndex(i)).npie)-1 %for the rest of soft pieces

        ld     = Tr.VLinks(Tr.LinkIndex(i)).lp{j};
        Gs     = Tr.VLinks(Tr.LinkIndex(i)).Gs{j};
        dof_here = VTwists(j+1).dof;
        nGauss = Tr.VLinks(Tr.LinkIndex(i)).nGauss{j};
        Xs     = Tr.VLinks(Tr.LinkIndex(i)).Xs{j};
        if ~strcmp(VTwists(j+1).Type,'Custom Dependent')
            dBqdq = VTwists(j+1).B;
        else
            Bh = VTwists(j+1).Bh; 
            dBqdq = zeros(6*nGauss,dof_here);
            q_here = q(dof_start:dof_start+dof_here-1); 
            for ii=2:nGauss-1
                [~,dBqdq_here] = Bh(Xs(ii),q_here);
                dBqdq((ii-1)*6+1:ii*6,:) = dBqdq_here;
            end
        end
        
        Dtemp  = zeros(dof_here,dof_here);
        Ws     = Tr.VLinks(Tr.LinkIndex(i)).Ws{j};
        

        %scaling of quantities
        Lscale        = ld;
        ld           = 1;

        for ii=2:nGauss-1
            Gs_here = Gs((ii-1)*6+1:ii*6,:);
            %scaling
            Gs_here(1:3,:) = Gs_here(1:3,:)/Lscale^3;
            Gs_here(4:6,:) = Gs_here(4:6,:)/Lscale;
            
            Dtemp = Dtemp+ld*Ws(ii)*dBqdq((ii-1)*6+1:ii*6,:)'*Gs_here*dBqdq((ii-1)*6+1:ii*6,:);
        end
        CD{i}{j+1} = Dtemp*Lscale^2; %scaling back 
        dof_start  = dof_start+dof_here;
    end
    
end

%construct D matrix:
D = [];
for i=1:Tr.N
    for j=1:Tr.VLinks(Tr.LinkIndex(i)).npie
        D = blkdiag(D,CD{i}{j});
    end
end

% q_scale = find_q_scale(Tr);
% D       = D./(q_scale*q_scale'); %actual D
end
