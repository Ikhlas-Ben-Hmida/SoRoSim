%Function that calculates the forward kinematics of the linkage from the base to the linkage tip at every significant points(24.05.2021)
%Last modified by Anup Teejo Mathew 02.03.2022
function g = FwdKinematics(Tr,q)

if isrow(q)
    q=q';
end

N         = Tr.N;
nsig      = Tr.nsig;
g_ini     = Tr.g_ini;
g_Ltip    = repmat(eye(4),N,1);
iLpre     = Tr.iLpre;

g         = zeros(4*nsig,4);
dof_start = 1;                         %starting dof of current piece
i_sig     = 1;

for i = 1:N
    
    if Tr.iLpre(i)>0
        g_here=g_Ltip((iLpre(i)-1)*4+1:iLpre(i)*4,:)*g_ini((i-1)*4+1:i*4,:);
    else
        g_here=g_ini((i-1)*4+1:i*4,:);
    end
    
    %Joint
    dof_here = Tr.CVTwists{i}(1).dof;
    q_here   = q(dof_start:dof_start+dof_here-1);
    B_here   = Tr.CVTwists{i}(1).B;
    xi_star  = Tr.CVTwists{i}(1).xi_star;
    
    if dof_here == 0                   %fixed joint (N)
        g_joint  = eye(4);
    else
        if Tr.VLinks(Tr.LinkIndex(i)).jointtype=='U'  %special case for universal joint. Considered as 2 revolute joints
            % first revolute joint
            xi      = B_here(:,1)*q_here(1)+xi_star;
            g_joint = variable_expmap_g(xi);
            g_here  = g_here*g_joint;
            % second revolute joint
            xi      = B_here(:,2)*q_here(2)+xi_star;
            g_joint = variable_expmap_g(xi);
        else
            xi      = B_here*q_here+xi_star;
            g_joint = variable_expmap_g(xi);
        end
    end

    g_here                     = g_here*g_joint;
    g((i_sig-1)*4+1:i_sig*4,:) = g_here;
    i_sig                      = i_sig+1;
    
    if Tr.VLinks(Tr.LinkIndex(i)).linktype == 'r'
        
        gi                         = Tr.VLinks(Tr.LinkIndex(i)).gi;
        g_here                     = g_here*gi;
        g((i_sig-1)*4+1:i_sig*4,:) = g_here;
        i_sig                      = i_sig+1;
        % bringing all quantities to the end of rigid link
        gf     = Tr.VLinks(Tr.LinkIndex(i)).gf;
        g_here = g_here*gf;
    end
    
    dof_start = dof_start+dof_here;
    
    for j = 1:Tr.VLinks(Tr.LinkIndex(i)).npie-1
        
        dof_here = Tr.CVTwists{i}(j+1).dof;
        q_here   = q(dof_start:dof_start+dof_here-1);
        xi_star  = Tr.CVTwists{i}(j+1).xi_star;
        gi       = Tr.VLinks(Tr.LinkIndex(i)).gi{j};
        Bdof     = Tr.CVTwists{i}(j+1).Bdof;
        Bodr     = Tr.CVTwists{i}(j+1).Bodr;
        lpf      = Tr.VLinks(Tr.LinkIndex(i)).lp{j};
        Xs       = Tr.VLinks(Tr.LinkIndex(i)).Xs{j};
        nGauss   = Tr.VLinks(Tr.LinkIndex(i)).nGauss{j};
        
        %Estimate B_scale
%         q_scale_here  = Tr.q_scale(dof_start:dof_start+dof_here-1);
%         doftheta_here = Bdof(1:3)'*(Bodr(1:3)+[1 1 1]');
%         q_scale_here(1:doftheta_here) = q_scale_here(1:doftheta_here)*lpf;
%         B_scale = repmat(q_scale_here',6*nGauss,1);
        
        if Tr.Z_order==4
            B_Z1       = Tr.CVTwists{i}(j+1).B_Z1;%./B_scale; %actual B
            B_Z2       = Tr.CVTwists{i}(j+1).B_Z2;%./B_scale; %actual B
        else %order 2
            B_Z        = Tr.CVTwists{i}(j+1).B_Z;%./B_scale; %actual B
        end
        
        %updating g, Jacobian, Jacobian_dot and eta at X=0
        g_here                     = g_here*gi;
        g((i_sig-1)*4+1:i_sig*4,:) = g_here;
        i_sig                      = i_sig+1;
        
        for ii = 2:nGauss

            H    = (Xs(ii)-Xs(ii-1))*lpf;
            if Tr.Z_order==4

                B_Z1here      = B_Z1(6*(ii-2)+1:6*(ii-1),:);%note this step
                B_Z2here      = B_Z2(6*(ii-2)+1:6*(ii-1),:);
                xi_starZ1here = xi_star(6*(ii-2)+1:6*(ii-1),2);
                xi_starZ2here = xi_star(6*(ii-2)+1:6*(ii-1),3);
                xi_Z1here     = B_Z1here*q_here+xi_starZ1here;
                xi_Z2here     = B_Z2here*q_here+xi_starZ2here;
                ad_xi_Z1here  = dinamico_adj(xi_Z1here);
                Gamma_here    = (H/2)*(xi_Z1here+xi_Z2here)+...
                                ((sqrt(3)*H^2)/12)*ad_xi_Z1here*xi_Z2here;      
            else % order 2
                B_Zhere       = B_Z(6*(ii-2)+1:6*(ii-1),:);%note this step
                xi_starZhere  = xi_star(6*(ii-2)+1:6*(ii-1),4);
                xi_Zhere      = B_Zhere*q_here+xi_starZhere;
                Gamma_here    = H*xi_Zhere;
            end
            gh                = variable_expmap_g(Gamma_here);

            %updating g, Jacobian, Jacobian_dot and eta
            g_here                     = g_here*gh;
            g((i_sig-1)*4+1:i_sig*4,:) = g_here;
            i_sig                      = i_sig+1;

        end
        gf        = Tr.VLinks(Tr.LinkIndex(i)).gf{j};
        g_here    = g_here*gf;
        dof_start = dof_start+dof_here;
        
    end
    g_Ltip((i-1)*4+1:i*4,:) = g_here; 
end

end


