%Computes the generalized stiffness matrix for the linkage
%Last modified by Anup Teejo Mathew 02.03.2022
function K = findK(Tr,q)
if nargin==1
    q=zeros(Tr.ndof);
end
CK = cell(Tr.N,1);

dof_start = 1;
for i=1:Tr.N
    
    CK{i}   = cell(Tr.VLinks(Tr.LinkIndex(i)).npie,1);
    VTwists = Tr.CVTwists{i};

    if Tr.VLinks(Tr.LinkIndex(i)).Kj==0
        CK{i}{1} = zeros(VTwists(1).dof);
    else
        if isequal(size(Tr.VLinks(Tr.LinkIndex(i)).Kj),[VTwists(1).dof,VTwists(1).dof])
            CK{i}{1} = Tr.VLinks(Tr.LinkIndex(i)).Kj;
        else
            uiwait(msgbox('Incorrect stiffness matrix dimensions','Error','error'));
            return
        end
    end
    dof_start = dof_start+VTwists(1).dof;  
    for j=1:(Tr.VLinks(Tr.LinkIndex(i)).npie)-1 %for the rest of soft link divisions
        
        ld     = Tr.VLinks(Tr.LinkIndex(i)).lp{j};
        Es     = Tr.VLinks(Tr.LinkIndex(i)).Es{j};
        dof_here    = VTwists(j+1).dof;
        nGauss = Tr.VLinks(Tr.LinkIndex(i)).nGauss{j};
        Xs     = Tr.VLinks(Tr.LinkIndex(i)).Xs{j};
        if ~strcmp(VTwists(j+1).Type,'Custom Dependent')
            dBqdq = VTwists(j+1).B;
        else
            Bh = VTwists(j+1).Bh; 
            dBqdq = zeros(6*nGauss,dof_here);
            q_here = q(dof_start:dof_start+dof_here-1); 
            for ii=2:nGauss-1
                [~,dBqdq_here] = Bh(Xs(ii),q_here);
                dBqdq((ii-1)*6+1:ii*6,:) = dBqdq_here;
            end
        end

        Ktemp  = zeros(dof_here,dof_here);
        Ws     = Tr.VLinks(Tr.LinkIndex(i)).Ws{j};
        %scaling of quantities
        Lscale        = ld;
        ld            = 1;
        
        for ii=2:nGauss-1
            Es_here = Es((ii-1)*6+1:ii*6,:);
            %scaling
            Es_here(1:3,:) = Es_here(1:3,:)/Lscale^3;
            Es_here(4:6,:) = Es_here(4:6,:)/Lscale;
            
            Ktemp = Ktemp+ld*Ws(ii)*dBqdq((ii-1)*6+1:ii*6,:)'*Es_here*dBqdq((ii-1)*6+1:ii*6,:);
        end
        CK{i}{j+1} = Ktemp*Lscale^2; %scaling back 
        dof_start  = dof_start+dof_here;
    end
    
end

%construct K matrix:
K = [];
for i=1:Tr.N
    for j=1:Tr.VLinks(Tr.LinkIndex(i)).npie
        K = blkdiag(K,CK{i}{j});
    end
end

% q_scale = find_q_scale(Tr);
% % K       = K./(q_scale*q_scale'); %actual K
end