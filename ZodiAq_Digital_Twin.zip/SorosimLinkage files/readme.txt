This folder contains the SorosimLinkage class which allows the user to define
different types of linkages by combining SorosimLinks.
Folder 'Input functions' contain functions to enable GUI
Folder 'Static and dynamic functions' contain functions used during the static and dynamic analyses
Folder 'Utility Functions'contains utility functions used during Sorosim Linkage creation
Folder 'Actuation' contains functions that are used to gather userinput for lumped (joint) actuation and distributed (cable) actuation.
The Twist class defines the dof of the system.