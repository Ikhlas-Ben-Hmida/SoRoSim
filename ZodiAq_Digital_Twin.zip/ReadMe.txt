%%Step 0
startup %run startup.m file

%%Step 1
%Load the digital twin (Linkage)
load('ZodiAqLinkage.mat') %ZodiAq linkage will be loaded on the workspace

%%Step 2
%Verify if CEFP (Custom External Force Present) is enabled, the value should be 1 (true)
ZodiAq.CEFP = true; %If enabled fluid interaction forces due to bouyancy
%and drag-lift are considered

%%Step 3
%If you want to use controller defined in CustomActuatorStrength.m file, make sure
%CAS property is enabled. Disable if you do not want to use.
ZodiAq.CAS = true;

%%Step 4
%Verify if ZodiAq.M_added and ZodiAq.CP1 are filled with precomputed values of
%added mass values and drag-lift matrices. To redo or modify, enter
ZodiAq.M_added = AddedMass(ZodiAq);
ZodiAq.CP1 = DragLiftMatrix(ZodiAq);

%%Step 5
%Edit desired trajectory in CustomActuatorStrength.m file

%%Step 6
ZodiAq.dynamics;
%Set the initial condition (zeros are okay) and simulation time
%Choose No, when asked if a plot is required in between the time integration
%This is a high DoF system, 1s simulation takes about 10 to 15 mins to compute

%%Step 7
%Choose yes to plot the video after simulation, alternatively
load('DynamicsSolution.mat') %loads t, qqd into the workspace and enter
ZodiAq.plotqqdN(ZodiAq,t,qqd)

%User can also disable the control law (ZodiAq.CAS = false;) and simply run dynamcis


