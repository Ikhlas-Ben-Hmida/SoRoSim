%Function that allows the user to define a custom external force, which is
%a function of eta dot, to be added to the default linkage mass matrix.
%In order to define the added mass use the comand: LinkageName.M_added = AddedMass(LinkageName)
%The default value of the added mass is equal to zero, if no custm added mass is defined
function M_added = AddedMass(Tr)

%-------------------------------------------------------------------------
% dynamic input environment

ro_water    = 1000;         % [Kg/m^3] water density

%-------------------------------------------------------------------------
% Geometrical input of body (assume a sphere of r = R_Zdq + 0.025)
% The added mass for a sphere is [(2*pi*r^3)/3]*rho_fluid (first 3 terms, the rest are zero.)

% Rb = 0.161352;
% Vol = (4*pi*Rb^3)/3;
Vol = 0.0087;
lambda = 0.5; 

Maddb    = ro_water*Vol*diag([0 0 0 lambda lambda lambda]);% added mass of a sphere in infinite fluid

%-------------------------------------------------------------------------
% Geometrical input of shaft

Rs       = Tr.VLinks(2).r(0);             % [m] Radius
Ls       = Tr.VLinks(2).L;                % [m] Length
As       = pi*Rs^2;                       % [m^2] Area
Vs       = As*Ls;                         % [m^3] volume

% Dynamic parameters
Blsy     = 1.5;                                    % [-] Added mass coef. in y
Blsz     = 1.5;                                    % [-] Added mass coef. in z
Madds    = ro_water*Vs*diag([0 0 0 0 Blsy Blsz]);  % addedd mass matrix

%-------------------------------------------------------------------------
% Geometrical input  Hook
Rh       = Tr.VLinks(3).r{1}(0);             % [m] Radius
nGauss   = Tr.VLinks(3).nGauss{1};
Ah       = pi*Rh^2;                       % [m^2]

% Dynamic parameters
Blhy     = 0.6;                                         % [-] added mass coeff
Blhz     = Blhy;                                        % [-] added mass coeff
Maddh    = ro_water*diag([0 0 0 0 Ah*Blhy Ah*Blhz]);    % added mass
Maddh    = repmat(Maddh,nGauss,1);

%-------------------------------------------------------------------------
% Geometrical input of filament

if Tr.VLinks(4).CS=='C'
    r        = Tr.VLinks(4).r{1};
    nGauss   = Tr.VLinks(4).nGauss{1};
    Xs       = Tr.VLinks(4).Xs{1};
    Blfy     = Blhy;                                   % [-] added mass coeff.
    Blfz     = Blhz;                                   % [-] added mass coeff.
    Maddf    = zeros(6*nGauss,6);

    for jj=1:nGauss
        Rf_here                               = r(Xs(jj));
        Af_here                               = pi*Rf_here^2;
        Maddf(6*(jj-1)+1:6*(jj-1)+6,:)        = ro_water*diag([0 0 0 0 Af_here*Blfy Af_here*Blfz]);
    end
else
    a        = Tr.VLinks(4).a{1};
    b        = Tr.VLinks(4).b{1};
    nGauss   = Tr.VLinks(4).nGauss{1};
    Xs       = Tr.VLinks(4).Xs{1};
    Blfy     = Blhy;                                   % [-] added mass coeff.
    Blfz     = Blhz;                                   % [-] added mass coeff.
    Maddf    = zeros(6*nGauss,6);

    for jj=1:nGauss
        Af_here                               = pi*a(Xs(jj))*b(Xs(jj));
        Maddf(6*(jj-1)+1:6*(jj-1)+6,:)        = ro_water*diag([0 0 0 0 Af_here*Blfy Af_here*Blfz]);
    end
end


%-------------------------------------------------------------------------


M_added  = [Maddb;...
    Madds;Maddh;Maddf;Madds;Maddh;Maddf;Madds;Maddh;Maddf;Madds;Maddh;Maddf;...
    Madds;Maddh;Maddf;Madds;Maddh;Maddf;Madds;Maddh;Maddf;Madds;Maddh;Maddf;...
    Madds;Maddh;Maddf;Madds;Maddh;Maddf;Madds;Maddh;Maddf;Madds;Maddh;Maddf];
end

