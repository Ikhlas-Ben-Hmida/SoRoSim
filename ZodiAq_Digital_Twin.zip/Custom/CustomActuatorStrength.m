%Function to calculate actuator strength as a function of system dynamics
%Last modified by Daniel 19.02.2024

function [w] = CustomActuatorStrength(Tr,q,g,J,t,qd,Jd,M,C,F,Bq)

%Tr: Linkage element,
%q and qd: joint coordinates and their time derivatives,
%g, J, Jd, and eta: transformation matrix, Jacobian, time derivative of jacobian, and screw velocity at every significant point of the linkage
%t:  time
%M,C,F,Bq: generalized mass, coriolis, force, and actuation matrices.
%u should be (nactx1) column vector where nact is the total number of actuators.
n = 6;
Xd = zeros(n,1);
dXd = zeros(n,1);
%% Desired values, Update here for different desired trajectories

% %Straightline x axis
% speed = 0.02; %m/s
% 
% Xd(3) = 0; % orientation about vertical axis (psi)
% Xd(4) = 0; % x coordinate
% Xd(5) = speed*t;  % y coordinate
% Xd(6) = 0;  % z coordinate
% 
% dXd(3) = 0;
% dXd(4) = 0;
% dXd(5) = speed;
% dXd(6) = 0;

%Circle
Rcir = 2;
t_final = 60;

Xd = zeros(n,1);
dXd = zeros(n,1);
w_frec = pi/t_final;

Xd(3) = pi*t/t_final; % orientation about vertical axis (psi)
Xd(4) = Rcir*cos(w_frec*t)-Rcir; % x coordinate
Xd(5) = -Rcir*sin(w_frec*t);  % y coordinate
Xd(6) = 0;  % z coordinate

dXd(3) = pi/t_final;
dXd(4) = -Rcir*w_frec*sin(w_frec*t);
dXd(5) = -Rcir*w_frec*cos(w_frec*t);
dXd(6) = 0;

%% Zodiaq position and orientation
% g_tip is a 4x4 matrix with g_tip(1:3,1:3) being the transformation matrix representing the 3d orientation
%and g_tip(1:3,4) being the position vector ([x,y,z]) of the system with respect to the global reference frame ([0,0,0])

eta = J*qd;
nact    = Tr.nact;
i_jactq = Tr.i_jactq;

%% Shell motion
g_now_shell = g(1:4,1:4);
eta_shell = eta(1:6);
Rm = g_now_shell(1:3,1:3);% rotation matrix


%% Shell pos and translational velocity: (x, y, z)
Shell_pos   = g_now_shell(1:3,4);
Shell_V_trans = eta(4:6);

%% Shell orientation and Rotational velocity:
xi_shell = piecewise_logmap(1,g_now_shell);
eul_log = xi_shell(1:3); %euler angle representation
% eul_shell = rotm2eul(Rm,'XYZ')'
eul_log = rotm2eul(Rm,'XYZ')';

Shell_V_Rot = eta(1:3);


%% Old angles and rotational speed passed to Zodiaq at t-dt
q_old  = zeros(1,nact);
qd_old = zeros(1,nact);
for i=1:nact %assign new input to motors
    q_old(i) = q(i_jactq(i));
    qd_old(i) = qd(i_jactq(i));
end

%% CONTROLLER CODE

% Dodecaedro

n = 6;
N_caras = 12;
m_zo = Tr.VLinks(1).Ms(4,4);
Ixx = Tr.VLinks(1).Ms(1,1);
Iyy = Tr.VLinks(1).Ms(2,2);
Izz = Tr.VLinks(1).Ms(3,3);
Ir = diag([Ixx,Iyy,Izz]);

% CREO TRAYECTORIA
% 
% Rcir = 2;
% t_final = 60;
% 
% Xd = zeros(n,1);
% dXd = zeros(n,1);
% w_frec = pi/t_final;
% 
% Xd(3) = pi*t/t_final;
% Xd(4) = Rcir*cos(w_frec*t)-Rcir;
% Xd(5) = -Rcir*sin(w_frec*t);
% Xd(6) = 0;
% dXd(3) = pi/t_final;
% dXd(4) = -Rcir*w_frec*sin(w_frec*t);
% dXd(5) = -Rcir*w_frec*cos(w_frec*t);
% dXd(6) = 0;


% Control de posiciones y orientacion en z

Pseudoinv_CK2 = [-60.5607   -0.8581   -1.1811   -5.3041
   45.1392    0.6396   -5.9766   -5.1892
  -20.1869    6.2353   -2.5126   -2.6411
   85.5130    5.2422    7.2152   -6.7641
  -20.1869   -4.3165    5.1537   -2.6411
   45.1392   -5.8818   -1.2386   -5.1892];


phi=eul_log(1);      
theta=eul_log(2);
psi=eul_log(3);
x=Shell_pos(1);
y=Shell_pos(2);
z=Shell_pos(3);
dphi=Shell_V_Rot(1);
dtheta=Shell_V_Rot(2);
dpsi=Shell_V_Rot(3);
dx=eta_shell(1);
dy=eta_shell(2);
dz=eta_shell(3);
X=[phi;theta;psi;x;y;z];
dX=[dphi;dtheta;dpsi;dx;dy;dz];

Rxzy = g(1:3,1:3);
M=[Ixx*eye(3),zeros(3,3);zeros(3,3),m_zo*eye(3)];

% DRAG AND LIFT FORCES AND TORQUES (Suponemos ZOdiaq es una esfera perfecta de Radio = Zodiaq.ru)

Cmbx     = 2.5;                             % [-] coeff. viscosità longitudinale
Cmby     = 2.5;                             % [-] coeff. viscosità trasversale
Cmbz     = 2.5;                             % [-] coeff. viscosità trasversale
Clbx     = 2.5;                             % [-] coeff. viscosità longitudinale
Clby     = 2.5;                             % [-] coeff. viscosità trasversale
Clbz     = 2.5;                             % [-] coeff. viscosità trasversale

Rb = 0.161352;

Ax = pi*Rb^2;
Ay = Ax;
Az = Ax;
Cr = 1;
Cx = Cr;
Cy = Cr;
Cz = Cr;
rho_w = 997;                 % Density of the fluid (water)

%%%%%%%%%%%%%%%%%%%%%%%% DRAG MATRIX %%%%%%%%%%%%%%%%%%%%%%%%%%%
D_matrix = 0.5*rho_w*diag([Cmbx*Ax*Rb^3,Cmby*Ay*Rb^3,Cmbz*Az*Rb^3,Clbx*Ax,Clby*Ay,Clbz*Az]);
mag_vel = sqrt(dx^2 + dy^2 + dz^2);
D_A= 4/3*pi*Rb^3*rho_w*diag([0, 0, 0, 0.5, 0.5, 0.5]);

FD = - mag_vel*D_matrix*dX;
FA = - D_matrix*dX;
F_fluid = FD+FA;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% OBTENGO VELOCIDADES CON LA LEY DE CONTROL

C = [inv(Ir)*[dtheta*dpsi*(Iyy-Izz);dphi*dpsi*(Izz-Ixx);dphi*dtheta*(Ixx-Iyy)];zeros(3,1)];

Kd = 0.1;
Kp = 5;

WW = [eye(3),zeros(3,3);zeros(3,3),Rxzy];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% CONTROL ONLY THE POSITIONS AND ORIENTATION ABOUT Z
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

 W2 = WW(3:6,3:6);
 M2 = M(3:6,3:6);

 V2 = inv(W2)*(M2*(-Kd*(dX(3:6)-dXd(3:6))-Kp*(X(3:6)-Xd(3:6)))+C(3:6).*dX(3:6)*1-F_fluid(3:6)*0);

%  V2 = inv(W2)*(M2*(-Kd*(dX(3:6)-dXd(3:6))-Kp*(X(3:6)-Xd(3:6)))+(C(3:6)+D_FT(3:6)).*dX(3:6)*1);

 OMEGA = Pseudoinv_CK2*V2;       % SE REFIERE A LAS CARAS 1 3 5 7 9 11

% Convierto los resultados de la ley de control en velocidades del sistema

    for kk=1:N_caras/2
       if(OMEGA(kk)>0)
           omega(2*kk-1:2*kk) = [abs(OMEGA(kk)) 0];                      
       else
           omega(2*kk-1:2*kk) = [0 abs(OMEGA(kk))];  
       end
    end


% Caras que le cambio el signo de giro (definicion del problema de control)

sat_omega = 4*pi;
ind = [3 4 7 8 11 12];       
omega(ind)=-omega(ind);

indices=find(abs(omega)>sat_omega);
omega(indices) = sat_omega*sign(omega(indices));

%% Uncomment to try arbitrary actuation inputs:
% omega=zeros(1,12);
% omega(3) = 5;
% omega(4) = 5;
w = omega; 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

end

