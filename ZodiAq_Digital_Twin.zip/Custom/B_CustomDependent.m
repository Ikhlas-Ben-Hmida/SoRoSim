function [Bq,dBqdq,dBqdt] = B_CustomDependent(X,varargin)
%Add more and change file name in twist if needed
%Bq should be linearly independent with others
Bq    = zeros(6,1); % for linear basis Bq = B*q

% example: non-linear gaussian bending about y axis
dof = 2; % define dof here
if isempty(varargin)
    q = zeros(100,1);
    t = 0;
else
    q = varargin{1};
    if nargin==3 
        t = varargin{2};
    end
end

dBqdq = zeros(6,dof);
dBqdt = zeros(6,1);

%Inverse Quadratic 2 dof

eps = q(1);
nu  = q(2);
k   = 1.65;
Bq(2) = k*eps/(eps^2*(X - nu)^2 + 1);

dBqdq(2,1) = k*1/(eps^2*(X - nu)^2 + 1) - (2*eps^2*(X - nu)^2)/(eps^2*(X - nu)^2 + 1)^2;
dBqdq(2,2) = k*(eps^3*(2*X - 2*nu))/(eps^2*(X - nu)^2 + 1)^2;
% % Gaussian 3 dof
% Bq(2) = q(3)*exp(-(X-q(1))^2*q(2)^2);
% 
% dBqdq(2,1) = q(3)*exp(-(X-q(1))^2*q(2)^2)*2*(X-q(1))*q(2)^2;
% dBqdq(2,2) = q(3)*exp(-(X-q(1))^2*q(2)^2)*(-(X-q(1))^2*2*q(2));
% dBqdq(2,3) = exp(-(X-q(1))^2*q(2)^2);
end