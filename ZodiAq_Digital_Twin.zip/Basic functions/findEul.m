% function [eul1 eul2 eul3] = findeul(g)
syms a b c

Rx = [1 0 0; 0 cos(a) -sin(a); 0 sin(a) cos(a)];
Ry = [cos(b) 0 sin(b); 0 1 0; -sin(b) 0 cos(b)];
Rz = [cos(c) -sin(c) 0; sin(c) cos(c) 0; 0 0 1];

Trans = Rx*Rz*Ry

[                       cos(b)*cos(c),       -sin(c),                        cos(c)*sin(b)]
[sin(a)*sin(b) + cos(a)*cos(b)*sin(c), cos(a)*cos(c), cos(a)*sin(b)*sin(c) - cos(b)*sin(a)]
[cos(b)*sin(a)*sin(c) - cos(a)*sin(b), cos(c)*sin(a), cos(a)*cos(b) + sin(a)*sin(b)*sin(c)]

vrrotmat2vec