%% Initializing:
Rho = 1000;
rcyl = 0.022;
s = 0.1;
lcyl = 0.05; %reduced
vol_dodeca = (s^3)*((15+7*sqrt(5))/4);
vol = vol_dodeca + 12* pi*rcyl^2*lcyl;

mass = Rho*vol; %- (12 * 150e-3);

d = -0.035; 

%% New CoM:
% CoM_ini = [0.15,0,0];
CoM_new = [0;0;d]; % Use tilde to make 3x3 and multiply by m
CoM_tilde = dinamico_tilde(CoM_new);
Mc = mass*CoM_tilde;


%% New MoI:

% MoI of Shell
phi = (1+sqrt(5))/2;
I = (mass*s^2*(39*phi+28))/150; %I of dodecahedron

Ix_new  = I + mass * d^2;
Iy_new  = I + mass * d^2;
Iz_new  = I;

MoI = [Ix_new 0 0;...
       0 Iy_new 0;...
       0 0 Iz_new];

MI_3 = mass*eye(3);

Ms = [MoI, Mc;...
      Mc' MI_3];

ZodiAq.VLinks(1).Ms = Ms; %Updating Property of Shell

