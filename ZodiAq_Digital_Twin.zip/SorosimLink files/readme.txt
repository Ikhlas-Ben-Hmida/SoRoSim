This folder contains the SorosimLink class which allows the user to define
different types of links as well as its methods: 
The LinkPropUpdate Function which allows the user to update and modify the 
property values as required after the link is created 