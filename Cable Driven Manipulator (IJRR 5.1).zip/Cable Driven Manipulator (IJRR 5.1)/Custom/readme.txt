The files in this folder can be modified by the user to include any custom
external and actuation forces and adjust the equivalent mass matrix for use 
in static and dynamic simulations. The defined forces can be saved in properties.