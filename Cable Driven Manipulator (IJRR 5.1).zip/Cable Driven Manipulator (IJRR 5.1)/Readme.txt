Step 1: Run startup.m
Step 2: Load files

For Legendre Basis
load('CDM_Leg.mat')

For FEM Basis
load('CDM_FEM.mat')

Step 3: Run dynamic simulation

S1.dynamics([],'ode15s')

Actuator strengths used in the paper: 
-15*(t-4).*heaviside(t-4) + 15*(t-6).*heaviside(t-6)
-20*(t-1).*heaviside(t-1) + 20*(t-3).*heaviside(t-3)
-30*(t).*heaviside(t) + 30*(t-4).*heaviside(t-4)
-25*(t-3).*heaviside(t-3) + 25*(t-5).*heaviside(t-5)

Choose simulation time from the dialog box. Eg. 8s
In the next dialog box of Graphical Output choose No.

Step 4: Get video output
Choose yes to generate the video in the dialog box that appear when the simulation finish.
Alternatively:
load('DynamicsSolution.mat')
plotqqd_CDM(S,t,qqd)